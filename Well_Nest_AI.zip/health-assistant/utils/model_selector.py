from typing import Dict, Any, List, Optional

class ModelSelector:
    """Utility class for selecting the appropriate model based on various factors"""
    
    def __init__(self, default_model: str = "gpt-4o-mini", advanced_model: str = "gpt-5-chat"):
        """Initialize the model selector
        
        Args:
            default_model: Name of the default model deployment
            advanced_model: Name of the advanced model deployment
        """
        self.default_model = default_model
        self.advanced_model = advanced_model
        
        # Complexity threshold for model selection
        self.COMPLEXITY_THRESHOLD = 0.6
        
        # Define agent types and their recommended models
        self.agent_model_mapping = {
            "orchestrator": self.default_model,
            "appointment_agent": self.default_model,
            "reminder": self.default_model,
            "medication_agent": self.advanced_model,
            "diagnosis": self.advanced_model,
            "treatment": self.advanced_model,
            "emergency_response_agent": self.advanced_model,
            "health_metrics_agent": self.default_model,
            "mental_health_agent": self.advanced_model,
            "nutrition_agent": self.default_model,
            "care_coordination_agent": self.default_model
        }
        
        # Define complexity indicators
        self.complex_medical_terms = [
            "diagnosis", "interaction", "contraindication", "pathology", 
            "etiology", "prognosis", "comorbidity", "pharmacokinetics",
            "pharmacodynamics", "pathophysiology", "epidemiology",
            "bioavailability", "metabolism", "clearance", "half-life",
            "therapeutic index", "adverse effect", "mechanism of action",
            "differential diagnosis", "complication", "side effect"
        ]
        
        self.critical_scenarios = [
            "emergency", "severe", "critical", "life-threatening", "urgent",
            "immediate attention", "crisis", "acute", "fatal", "lethal",
            "overdose", "anaphylaxis", "shock", "seizure", "stroke", "cardiac",
            "hemorrhage", "bleeding", "unconscious", "collapse", "trauma"
        ]
        
        self.complex_reasoning_indicators = [
            "compare", "analyze", "evaluate", "synthesize", "differentiate",
            "explain the relationship", "what are the implications",
            "how would you assess", "what factors contribute to",
            "interpret", "predict", "correlate", "distinguish between",
            "what is the mechanism", "how does", "why does", "contrast",
            "underlying cause", "potential complications", "long-term effects"
        ]
        
        # Define task types and their complexity levels
        self.task_complexity = {
            "orchestration": 0.3,
            "appointment_scheduling": 0.2,
            "reminder_setting": 0.1,
            "medication_management": 0.6,
            "medication_interaction": 0.8,
            "symptom_analysis": 0.7,
            "diagnosis_assistance": 0.9,
            "treatment_planning": 0.8,
            "emergency_triage": 0.9,
            "health_monitoring": 0.5,
            "mental_health_support": 0.7,
            "nutrition_advice": 0.5,
            "care_coordination": 0.6
        }
    
    def select_model(self, query: str, context: Dict[str, Any] = None) -> str:
        """Select the appropriate model based on query complexity and context"""
        context = context or {}
        
        # Default to the more efficient model
        model = self.default_model
        
        # If an agent_id is specified, use the agent-specific model
        agent_id = context.get("agent_id")
        if agent_id and agent_id in self.agent_model_mapping:
            model = self.agent_model_mapping[agent_id]
            # But still check other factors
        
        # If a task_type is specified, consider its complexity
        task_type = context.get("task_type")
        if task_type and task_type in self.task_complexity:
            task_complexity = self.task_complexity[task_type]
            if task_complexity > self.COMPLEXITY_THRESHOLD:
                model = self.advanced_model
        
        # Check for query complexity
        query_complexity = self._assess_query_complexity(query)
        
        # Check if this is a follow-up to a complex conversation
        is_complex_conversation = context.get("conversation_complexity", 0) > 3
        
        # Check if user has opted for premium responses
        premium_user = context.get("user_tier") == "premium"
        
        # Check if we're approaching the cost threshold
        approaching_threshold = context.get("approaching_cost_threshold", False)
        
        # Check if advanced model is unavailable
        advanced_model_unavailable = context.get("advanced_model_unavailable", False)
        
        # Determine if we should use the advanced model
        if not advanced_model_unavailable and not approaching_threshold and (
            (query_complexity > self.COMPLEXITY_THRESHOLD) or 
            is_complex_conversation or 
            premium_user
        ):
            return self.advanced_model
        
        return model
    
    def select_model_for_agent(self, agent_id: str, query: str = None, context: Dict[str, Any] = None) -> str:
        """Select the appropriate model for a specific agent"""
        context = context or {}
        
        # Add agent_id to context
        context["agent_id"] = agent_id
        
        # Map agent to task type if not already specified
        if "task_type" not in context:
            agent_to_task = {
                "orchestrator": "orchestration",
                "appointment_agent": "appointment_scheduling",
                "reminder": "reminder_setting",
                "medication_agent": "medication_management",
                "diagnosis": "diagnosis_assistance",
                "treatment": "treatment_planning",
                "emergency_response_agent": "emergency_triage",
                "health_metrics_agent": "health_monitoring",
                "mental_health_agent": "mental_health_support",
                "nutrition_agent": "nutrition_advice",
                "care_coordination_agent": "care_coordination"
            }
            context["task_type"] = agent_to_task.get(agent_id, "orchestration")
        
        # If query is provided, use the full selection logic
        if query:
            return self.select_model(query, context)
        
        # Otherwise, use the agent-specific default model
        if agent_id in self.agent_model_mapping:
            # Check if we're approaching cost threshold
            if context.get("approaching_cost_threshold", False):
                return self.default_model
                
            # Check if advanced model is unavailable
            if context.get("advanced_model_unavailable", False) and self.agent_model_mapping[agent_id] == self.advanced_model:
                return self.default_model
                
            return self.agent_model_mapping[agent_id]
        
        return self.default_model
    
    def _assess_query_complexity(self, query: str) -> float:
        """Assess the complexity of a query on a scale from 0.0 to 1.0"""
        if not query:
            return 0.0
            
        query = query.lower()
        complexity_score = 0.0
        
        # Check for complex medical terms
        for term in self.complex_medical_terms:
            if term in query:
                complexity_score += 0.2
                break
        
        # Check for critical scenarios
        for term in self.critical_scenarios:
            if term in query:
                complexity_score += 0.3
                break
        
        # Check for complex reasoning indicators
        for indicator in self.complex_reasoning_indicators:
            if indicator in query:
                complexity_score += 0.2
                break
        
        # Check query length (longer queries tend to be more complex)
        if len(query) > 100:
            complexity_score += 0.1
        
        if len(query) > 200:
            complexity_score += 0.1
        
        # Check for question marks (multiple questions tend to be more complex)
        question_count = query.count('?')
        if question_count > 1:
            complexity_score += 0.1 * min(question_count, 3)  # Cap at 0.3
        
        # Cap the complexity score at 1.0
        return min(complexity_score, 1.0)
    
    def get_complexity_explanation(self, query: str) -> Dict[str, Any]:
        """Get a detailed explanation of the query complexity assessment"""
        if not query:
            return {
                "query": "",
                "overall_complexity": 0.0,
                "factors": []
            }
            
        query_lower = query.lower()
        explanation = {
            "query": query,
            "overall_complexity": 0.0,
            "factors": []
        }
        
        # Check for complex medical terms
        for term in self.complex_medical_terms:
            if term in query_lower:
                explanation["factors"].append({
                    "factor": "complex_medical_term",
                    "term": term,
                    "contribution": 0.2
                })
                break
        
        # Check for critical scenarios
        for term in self.critical_scenarios:
            if term in query_lower:
                explanation["factors"].append({
                    "factor": "critical_scenario",
                    "term": term,
                    "contribution": 0.3
                })
                break
        
        # Check for complex reasoning indicators
        for indicator in self.complex_reasoning_indicators:
            if indicator in query_lower:
                explanation["factors"].append({
                    "factor": "complex_reasoning",
                    "term": indicator,
                    "contribution": 0.2
                })
                break
        
        # Check query length
        if len(query) > 100:
            explanation["factors"].append({
                "factor": "query_length",
                "length": len(query),
                "contribution": 0.1
            })
        
        if len(query) > 200:
            explanation["factors"].append({
                "factor": "query_length_extended",
                "length": len(query),
                "contribution": 0.1
            })
        
        # Check for question marks
        question_count = query.count('?')
        if question_count > 1:
            contribution = 0.1 * min(question_count, 3)
            explanation["factors"].append({
                "factor": "multiple_questions",
                "count": question_count,
                "contribution": contribution
            })
        
        # Calculate overall complexity
        explanation["overall_complexity"] = min(
            sum(factor["contribution"] for factor in explanation["factors"]),
            1.0
        )
        
        return explanation
    
    def recommend_model(self, query: str, context: Dict[str, Any] = None) -> Dict[str, Any]:
        """Provide a recommendation with explanation for model selection"""
        context = context or {}
        complexity_explanation = self.get_complexity_explanation(query)
        selected_model = self.select_model(query, context)
        
        recommendation = {
            "selected_model": selected_model,
            "complexity_assessment": complexity_explanation,
            "context_factors": {
                "agent_id": context.get("agent_id", "none"),
                "task_type": context.get("task_type", "none"),
                "conversation_complexity": context.get("conversation_complexity", 0),
                "user_tier": context.get("user_tier", "standard"),
                "approaching_cost_threshold": context.get("approaching_cost_threshold", False),
                "advanced_model_unavailable": context.get("advanced_model_unavailable", False)
            },
            "explanation": ""
        }
        
        # Generate explanation
        if selected_model == self.advanced_model:
            if context.get("agent_id") in self.agent_model_mapping and self.agent_model_mapping[context.get("agent_id")] == self.advanced_model:
                recommendation["explanation"] = f"Selected {self.advanced_model} because the {context.get('agent_id')} agent requires advanced reasoning capabilities."
            elif context.get("task_type") in self.task_complexity and self.task_complexity[context.get("task_type")] > self.COMPLEXITY_THRESHOLD:
                recommendation["explanation"] = f"Selected {self.advanced_model} because {context.get('task_type')} tasks require advanced reasoning capabilities."
            elif context.get("user_tier") == "premium":
                recommendation["explanation"] = f"Selected {self.advanced_model} because user has premium tier access."
            elif context.get("conversation_complexity", 0) > 3:
                recommendation["explanation"] = f"Selected {self.advanced_model} due to complex conversation history."
            elif complexity_explanation["overall_complexity"] > self.COMPLEXITY_THRESHOLD:
                recommendation["explanation"] = f"Selected {self.advanced_model} due to high query complexity."
            else:
                recommendation["explanation"] = f"Selected {self.advanced_model} based on combined factors."
        else:
            if context.get("advanced_model_unavailable", False):
                recommendation["explanation"] = f"Selected {self.default_model} because {self.advanced_model} is currently unavailable."
            elif context.get("approaching_cost_threshold", False):
                recommendation["explanation"] = f"Selected {self.default_model} to stay within cost thresholds."
            else:
                recommendation["explanation"] = f"Selected {self.default_model} as query doesn't require advanced capabilities."
        
        return recommendation
    
    def get_model_capabilities(self, model_name: str = None) -> Dict[str, Any]:
        """Return information about model capabilities"""
        if model_name is None or model_name == self.default_model:
            return {
                "name": self.default_model,
                "strengths": [
                    "Very fast response time",
                    "Extremely cost-effective for all queries",
                    "Excellent for basic information retrieval and summarization",
                    "Efficient for orchestration tasks"
                ],
                "limitations": [
                    "Less nuanced understanding of complex medical concepts",
                    "May provide less detailed explanations",
                ],
                "recommended_for": [
                    "Orchestration between agents",
                    "Basic health information",
                    "Simple medication reminders",
                    "Routine appointment scheduling",
                    "General wellness advice"
                ],
                "recommended_agents": [
                    "orchestrator",
                    "appointment_agent",
                    "health_metrics_agent",
                    "nutrition_agent",
                    "care_coordination_agent"
                ]
            }
        elif model_name == self.advanced_model:
            return {
                "name": self.advanced_model,
                "strengths": [
                    "Superior reasoning capabilities",
                    "Excellent understanding of complex medical concepts",
                    "More nuanced responses to ambiguous queries",
                    "Better at synthesizing information from multiple domains",
                    "More accurate for specialized medical knowledge"
                ],
                "limitations": [
                    "Higher cost",
                    "Slightly slower response time than mini",
                    "Overkill for simple queries"
                ],
                "recommended_for": [
                    "Complex medical reasoning",
                    "Detailed explanations of disease mechanisms",
                    "Analysis of multiple factors in health conditions",
                    "Nuanced interpretation of symptoms",
                    "Critical health scenarios requiring careful analysis",
                    "Medication interaction analysis",
                    "Mental health support requiring empathy"
                ],
                "recommended_agents": [
                    "medication_agent",
                    "diagnosis",
                    "treatment",
                    "emergency_response_agent",
                    "mental_health_agent"
                ]
            }