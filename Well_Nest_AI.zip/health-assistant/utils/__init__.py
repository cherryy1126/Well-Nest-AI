# health-assistant/utils/__init__.py

"""
Utility modules for the Health and Wellness Assistant.

This package contains utility classes and functions used throughout the application,
including Azure AI service integration and model selection logic.
"""

from .azure_ai_service import AzureAIAgentService
from .model_selector import ModelSelector

__all__ = ['AzureAIAgentService', 'ModelSelector']
