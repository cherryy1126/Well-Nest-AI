# health-assistant/utils/azure_ai_service.py

import os
import json
import time
import asyncio
import aiohttp
from typing import Dict, Any, List, Optional
from dotenv import load_dotenv
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("AzureAIService")

class AzureAIAgentService:
    """Service for interacting with Azure OpenAI for the WellNest AI health assistant"""
    
    def __init__(self):
        """Initialize the Azure AI service"""
        # Load environment variables
        load_dotenv()
        
        # Set up Azure OpenAI API credentials
        self.api_key = os.getenv("AZURE_OPENAI_API_KEY")
        self.endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
        self.api_version = os.getenv("AZURE_OPENAI_API_VERSION", "2023-12-01-preview")
        
        # Model configurations
        self.models = {
            "gpt-35-turbo": {
                "deployment_id": os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME_35", "gpt-35-turbo"),
                "max_tokens": 4096,
                "cost_per_1k_input_tokens": 0.0015,
                "cost_per_1k_output_tokens": 0.002,
                "recommended_for": ["orchestration", "basic_queries", "appointment_scheduling", "reminders"]
            },
            "gpt-4o-mini": {
                "deployment_id": os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME_4O_MINI", "gpt-4o-mini"),
                "max_tokens": 8192,
                "cost_per_1k_input_tokens": 0.005,
                "cost_per_1k_output_tokens": 0.015,
                "recommended_for": ["medical_reasoning", "complex_queries", "diagnosis", "treatment_planning"]
            }
        }
        
        # Default model
        self.default_model = "gpt-35-turbo"
        
        # Usage tracking
        self.usage_stats = {
            "total_tokens": 0,
            "total_cost": 0.0,
            "daily_tokens": 0,
            "daily_cost": 0.0,
            "last_reset": time.time(),
            "calls_by_model": {},
            "approaching_threshold": False,
            "cost_threshold": float(os.getenv("COST_THRESHOLD", "5.0"))
        }
        
        # Initialize HTTP session
        self.session = None
        
        # Check if credentials are valid
        if not self.api_key or not self.endpoint:
            logger.warning("Azure OpenAI credentials not found. Some features may not work.")
    
    async def _ensure_session(self):
        """Ensure HTTP session is initialized"""
        if self.session is None or self.session.closed:
            self.session = aiohttp.ClientSession()
    
    async def close(self):
        """Close the HTTP session"""
        if self.session and not self.session.closed:
            await self.session.close()
            self.session = None
    
    async def invoke_model(self, 
                          messages: List[Dict[str, str]], 
                          deployment_id: str = None,
                          temperature: float = 0.7,
                          max_tokens: int = None,
                          functions: List[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Invoke an Azure OpenAI model
        
        Args:
            messages: List of messages in the conversation
            deployment_id: Model deployment ID (or model name)
            temperature: Temperature for response generation
            max_tokens: Maximum tokens in the response
            functions: List of function definitions
            
        Returns:
            Model response
        """
        await self._ensure_session()
        
        # Map model name to deployment ID if needed
        if deployment_id in self.models:
            actual_deployment_id = self.models[deployment_id]["deployment_id"]
        else:
            actual_deployment_id = deployment_id or self.models[self.default_model]["deployment_id"]
        
        # Get model info for tracking
        model_key = deployment_id or self.default_model
        
        # Use model-specific max tokens if not provided
        if max_tokens is None:
            max_tokens = self.models.get(model_key, {}).get("max_tokens", 800)
        
        # Prepare request
        url = f"{self.endpoint}/openai/deployments/{actual_deployment_id}/chat/completions?api-version={self.api_version}"
        
        headers = {
            "Content-Type": "application/json",
            "api-key": self.api_key
        }
        
        # Build request body
        body = {
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "top_p": 0.95,
            "frequency_penalty": 0.0,
            "presence_penalty": 0.0
        }
        
        # Add functions if provided
        if functions:
            # Convert functions to tools format if using newer API version
            if self.api_version >= "2023-12-01-preview":
                body["tools"] = [{"type": "function", "function": func} for func in functions]
            else:
                body["functions"] = functions
        
        # Track start time for performance monitoring
        start_time = time.time()
        
        try:
            async with self.session.post(url, headers=headers, json=body) as response:
                if response.status != 200:
                    error_text = await response.text()
                    logger.error(f"Azure OpenAI API error: {response.status} - {error_text}")
                    raise Exception(f"Azure OpenAI API error: {response.status} - {error_text}")
                
                result = await response.json()
                
                # Calculate elapsed time
                elapsed_time = time.time() - start_time
                
                # Update usage statistics
                self._update_usage_stats(result, model_key)
                
                # Add metadata to the response
                result["_metadata"] = {
                    "model": model_key,
                    "elapsed_time": elapsed_time,
                    "timestamp": time.time()
                }
                
                return result
                
        except aiohttp.ClientError as e:
            logger.error(f"HTTP error when calling Azure OpenAI: {e}")
            raise Exception(f"Failed to communicate with Azure OpenAI: {e}")
    
    async def invoke_agent(self, 
                          agent_id: str, 
                          message: str, 
                          conversation_id: str = None,
                          context: Dict[str, Any] = None) -> Dict[str, Any]:
        """Invoke an agent with a message
        
        Args:
            agent_id: ID of the agent to invoke
            message: User message
            conversation_id: Optional conversation ID
            context: Additional context
            
        Returns:
            Agent response
        """
        # Define system prompts for WellNest AI agents
        system_prompts = {
            "appointment_agent": "You are an Appointment Scheduling Agent for WellNest AI healthcare services. Help elderly users schedule, reschedule, or cancel appointments with healthcare providers.",
            "medication_agent": "You are a Medication Management Agent for WellNest AI healthcare services. Help elderly users track medications, set reminders, and provide information about medications.",
            "health_metrics_agent": "You are a Health Metrics Agent for WellNest AI healthcare services. Help elderly users track health metrics, analyze trends, and set health goals.",
            "mental_health_agent": "You are a Mental Health Support Agent for WellNest AI. Help elderly users track mood, manage stress, and provide mental wellness suggestions.",
            "nutrition_agent": "You are a Nutrition Agent for WellNest AI healthcare services. Help elderly users with meal plans, nutritional information, and food-medication interactions.",
            "care_coordination_agent": "You are a Care Coordination Agent for WellNest AI healthcare services. Help elderly users coordinate care across multiple healthcare providers and ensure continuity of care.",
            "emergency_response_agent": "You are an Emergency Response Agent for WellNest AI healthcare services. Help elderly users identify potential medical emergencies and provide appropriate guidance."
        }
        
        # Get the system prompt for the agent
        system_prompt = system_prompts.get(agent_id, "You are a helpful WellNest AI healthcare assistant for elderly care.")
        
        # Prepare messages
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": message}
        ]
        
        # Add conversation history if available in context
        if context and "conversation_history" in context:
            history = context["conversation_history"]
            if history:
                # Remove system message
                messages.pop(0)
                # Add history messages
                for entry in history:
                    messages.append({"role": "user", "content": entry.get("user_message", "")})
                    messages.append({"role": "assistant", "content": entry.get("assistant_response", "")})
                # Re-add system message at the beginning
                messages.insert(0, {"role": "system", "content": system_prompt})
        
        # Map agent types to task types for model selection
        agent_to_task = {
            "appointment_agent": "appointment_scheduling",
            "medication_agent": "medication_interaction",
            "health_metrics_agent": "health_monitoring",
            "mental_health_agent": "mental_health_support",
            "nutrition_agent": "nutrition_guidance",
            "care_coordination_agent": "care_coordination",
            "emergency_response_agent": "emergency_response"
        }
        
        # Get the task type for this agent
        task_type = agent_to_task.get(agent_id, "general_assistance")
        
        # Select model based on context or task type
        model = context.get("model") if context and "model" in context else self.get_model_for_task(task_type)
        
        # Invoke the model
        response = await self.invoke_model(
            messages=messages,
            deployment_id=model
        )
        
        # Format the response
        result = {
            "agent_id": agent_id,
            "conversation_id": conversation_id,
            "message": response["choices"][0]["message"]["content"],
            "usage": response.get("usage", {}),
            "model": model
        }
        
        return result
    
    def get_model_for_task(self, task_type: str) -> str:
        """Get the appropriate model for a specific task type"""
        # Tasks that benefit from more advanced reasoning
        advanced_tasks = [
            "medication_interaction", 
            "emergency_response", 
            "mental_health_support",
            "complex_medical_query"
        ]
        
        # Standard tasks that work well with the default model
        standard_tasks = [
            "appointment_scheduling",
            "health_monitoring",
            "nutrition_guidance",
            "care_coordination",
            "general_assistance"
        ]
        
        if task_type.lower() in advanced_tasks:
            return "gpt-4o-mini"
        else:
            return self.default_model
    
    def _update_usage_stats(self, response: Dict[str, Any], model_key: str):
        """Update usage statistics based on API response
        
        Args:
            response: API response
            model_key: Model key for tracking
        """
        if "usage" not in response:
            return
            
        usage = response["usage"]
        prompt_tokens = usage.get("prompt_tokens", 0)
        completion_tokens = usage.get("completion_tokens", 0)
        total_tokens = usage.get("total_tokens", 0)
        
        # Get cost rates for the model
        model_info = self.models.get(model_key, self.models[self.default_model])
        input_cost_rate = model_info.get("cost_per_1k_input_tokens", 0.0015)
        output_cost_rate = model_info.get("cost_per_1k_output_tokens", 0.002)
        
        # Calculate cost
        input_cost = (prompt_tokens / 1000) * input_cost_rate
        output_cost = (completion_tokens / 1000) * output_cost_rate
        total_cost = input_cost + output_cost
        
        # Update global stats
        self.usage_stats["total_tokens"] += total_tokens
        self.usage_stats["total_cost"] += total_cost
        self.usage_stats["daily_tokens"] += total_tokens
        self.usage_stats["daily_cost"] += total_cost
        
        # Update model-specific stats
        if model_key not in self.usage_stats["calls_by_model"]:
            self.usage_stats["calls_by_model"][model_key] = {
                "calls": 0,
                "tokens": 0,
                "cost": 0.0
            }
            
        self.usage_stats["calls_by_model"][model_key]["calls"] += 1
        self.usage_stats["calls_by_model"][model_key]["tokens"] += total_tokens
        self.usage_stats["calls_by_model"][model_key]["cost"] += total_cost
        
        # Check if approaching cost threshold
        threshold = self.usage_stats["cost_threshold"]
        daily_cost = self.usage_stats["daily_cost"]
        
        # Set flag if we've used 80% of the daily budget
        self.usage_stats["approaching_threshold"] = daily_cost >= (threshold * 0.8)
        
        # Log if we're approaching the threshold
        if self.usage_stats["approaching_threshold"] and daily_cost >= (threshold * 0.9):
            logger.warning(f"Approaching daily cost threshold: ${daily_cost:.2f} / ${threshold:.2f}")
    
    def get_usage_stats(self) -> Dict[str, Any]:
        """Get current usage statistics
        
        Returns:
            Dictionary with usage statistics
        """
        # Check if we need to reset daily stats (24 hours since last reset)
        if time.time() - self.usage_stats.get("last_reset", 0) > 86400:  # 24 hours in seconds
            self.usage_stats["daily_tokens"] = 0
            self.usage_stats["daily_cost"] = 0.0
            self.usage_stats["last_reset"] = time.time()
            self.usage_stats["approaching_threshold"] = False
        
        return self.usage_stats
    
    def reset_usage_stats(self):
        """Reset usage statistics"""
        self.usage_stats = {
            "total_tokens": 0,
            "total_cost": 0.0,
            "daily_tokens": 0,
            "daily_cost": 0.0,
            "last_reset": time.time(),
            "calls_by_model": {},
            "approaching_threshold": False,
            "cost_threshold": self.usage_stats.get("cost_threshold", 5.0)
        }
    
    def get_model_info(self, model_name: str = None) -> Dict[str, Any]:
        """Get information about a model
        
        Args:
            model_name: Name of the model
            
        Returns:
            Model information
        """
        if model_name and model_name in self.models:
            return self.models[model_name]
        elif not model_name:
            return self.models
        else:
            return {"error": f"Unknown model: {model_name}"}
