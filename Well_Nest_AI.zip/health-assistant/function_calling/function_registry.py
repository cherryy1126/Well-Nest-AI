import inspect
from typing import Dict, Any, List, Callable, Optional, get_type_hints, Union, Type

class FunctionRegistry:
    """Registry for functions that can be called by agents"""
    
    def __init__(self):
        """Initialize the function registry"""
        self.functions: Dict[str, Callable] = {}
        self.function_schemas: Dict[str, Dict[str, Any]] = {}
        self.semantic_functions: Dict[str, Dict[str, str]] = {}
        
    def register(self, func: Callable) -> None:
        """Register a function with the registry
        
        Args:
            func: Function to register
        """
        func_name = func.__name__
        self.functions[func_name] = func
        
        # Generate OpenAI-compatible function schema
        schema = self._generate_schema(func)
        self.function_schemas[func_name] = schema
        
    def register_functions(self, functions: List[Callable]) -> None:
        """Register multiple functions with the registry
        
        Args:
            functions: List of functions to register
        """
        for func in functions:
            self.register(func)
    
    def register_semantic_function(self, skill_name: str, function_name: str, description: str) -> None:
        """Register a Semantic Kernel function
        
        Args:
            skill_name: Name of the skill
            function_name: Name of the function
            description: Description of the function
        """
        full_name = f"{skill_name}.{function_name}"
        self.semantic_functions[full_name] = {
            "skill_name": skill_name,
            "function_name": function_name,
            "description": description
        }
        
        # Also create a function schema for it
        schema = {
            "name": full_name,
            "description": description,
            "parameters": {
                "type": "object",
                "properties": {},
                "required": []
            }
        }
        self.function_schemas[full_name] = schema
            
    def get_function(self, name: str) -> Optional[Callable]:
        """Get a registered function by name
        
        Args:
            name: Name of the function
            
        Returns:
            Function or None if not found
        """
        return self.functions.get(name)
    
    def get_semantic_function(self, name: str) -> Optional[Dict[str, str]]:
        """Get a registered semantic function by name
        
        Args:
            name: Name of the function (skill.function format)
            
        Returns:
            Semantic function info or None if not found
        """
        return self.semantic_functions.get(name)
    
    def get_schema(self, name: str) -> Optional[Dict[str, Any]]:
        """Get the schema for a registered function
        
        Args:
            name: Name of the function
            
        Returns:
            Schema or None if not found
        """
        return self.function_schemas.get(name)
    
    def get_all_schemas(self) -> List[Dict[str, Any]]:
        """Get schemas for all registered functions
        
        Returns:
            List of function schemas
        """
        return list(self.function_schemas.values())
    
    def get_all_functions(self) -> Dict[str, Callable]:
        """Get all registered functions
        
        Returns:
            Dictionary of function names to functions
        """
        return self.functions.copy()
    
    def get_all_semantic_functions(self) -> Dict[str, Dict[str, str]]:
        """Get all registered semantic functions
        
        Returns:
            Dictionary of function names to semantic function info
        """
        return self.semantic_functions.copy()
    
    def _generate_schema(self, func: Callable) -> Dict[str, Any]:
        """Generate an OpenAI-compatible function schema
        
        Args:
            func: Function to generate schema for
            
        Returns:
            Function schema
        """
        sig = inspect.signature(func)
        doc = inspect.getdoc(func) or ""
        type_hints = get_type_hints(func)
        
        # Extract the first line as the description
        description = doc.split("\n")[0] if doc else ""
        
        # Build the parameter schema
        parameters = {
            "type": "object",
            "properties": {},
            "required": []
        }
        
        for name, param in sig.parameters.items():
            # Skip self parameter for methods
            if name == "self":
                continue
                
            # Get parameter type
            param_type = type_hints.get(name, Any)
            param_schema = self._get_param_schema(param_type)
            
            # Look for parameter description in docstring
            param_desc = self._extract_param_description(doc, name)
            if param_desc:
                param_schema["description"] = param_desc
            
            # Add parameter to schema
            parameters["properties"][name] = param_schema
            
            # Check if parameter is required
            if param.default == inspect.Parameter.empty:
                parameters["required"].append(name)
        
        # Build the complete schema
        schema = {
            "name": func.__name__,
            "description": description,
            "parameters": parameters
        }
        
        return schema
        
    def register_with_custom_schema(self, func: Callable, schema: Dict[str, Any]) -> None:
        """Register a function with a custom schema

        Args:
            func: Function to register
            schema: Custom schema for the function
        """
        func_name = func.__name__
        self.functions[func_name] = func
        self.function_schemas[func_name] = schema

    
    def _extract_param_description(self, docstring: str, param_name: str) -> Optional[str]:
        """Extract parameter description from docstring
        
        Args:
            docstring: Function docstring
            param_name: Parameter name
            
        Returns:
            Parameter description or None if not found
        """
        if not docstring:
            return None
            
        lines = docstring.split("\n")
        param_marker = f"Args:"
        param_prefix = f"{param_name}:"
        
        # Find the Args section
        args_line = -1
        for i, line in enumerate(lines):
            if param_marker in line:
                args_line = i
                break
                
        if args_line == -1:
            return None
            
        # Find the parameter
        for i in range(args_line + 1, len(lines)):
            # FIX: Use lines[i] instead of reusing 'line' from the previous loop
            current_line = lines[i]
            line_stripped = current_line.strip()
            
            if line_stripped.startswith(param_prefix):
                return line_stripped[len(param_prefix):].strip()
            # FIX: Check indentation on original line and content on stripped line
            elif line_stripped and not line_stripped.endswith(":") and not current_line.startswith(" "):
                # We've reached the end of the Args section
                break
                
        return None
    
    def _get_param_schema(self, param_type: Any) -> Dict[str, Any]:
        """Convert a Python type to a JSON schema type
        
        Args:
            param_type: Python type
            
        Returns:
            JSON schema type
        """
        # Handle basic types
        if param_type == str:
            return {"type": "string"}
        elif param_type == int:
            return {"type": "integer"}
        elif param_type == float:
            return {"type": "number"}
        elif param_type == bool:
            return {"type": "boolean"}
        
        # Handle more complex types
        origin = getattr(param_type, "__origin__", None)
        args = getattr(param_type, "__args__", [])
        
        # Handle Lists
        if origin == list or origin == List:
            if args and len(args) == 1:
                item_type = self._get_param_schema(args[0])
                return {"type": "array", "items": item_type}
            return {"type": "array"}
        
        # Handle Dictionaries
        elif origin == dict or origin == Dict:
            return {"type": "object"}
        
        # Handle Optional types
        elif origin == Union and type(None) in args:
            # Get the non-None type
            non_none_args = [arg for arg in args if arg != type(None)]
            if len(non_none_args) == 1:
                return self._get_param_schema(non_none_args[0])
        
        # Default to string for complex types
        return {"type": "string"}
    
    def convert_to_openai_tools(self) -> List[Dict[str, Any]]:
        """Convert function schemas to OpenAI tools format
        
        Returns:
            List of tools in OpenAI format
        """
        tools = []
        
        for schema in self.function_schemas.values():
            tools.append({
                "type": "function",
                "function": schema
            })
            
        return tools