# function_calling/__init__.py

"""
Function calling framework for the Health and Wellness Assistant.

This package provides the infrastructure for agents to call functions,
including function registration, schema generation, and execution.
It supports both standard Python functions and Semantic Kernel functions.
"""

from .function_registry import FunctionRegistry
from .function_executor import FunctionExecutor

__all__ = ['FunctionRegistry', 'FunctionExecutor']
