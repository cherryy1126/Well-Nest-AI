import json
from typing import Dict, Any, List, Optional
from .function_registry import FunctionRegistry

class FunctionExecutor:
    """Executes functions based on agent requests"""
    
    def __init__(self, registry: FunctionRegistry):
        """Initialize the function executor
        
        Args:
            registry: Function registry
        """
        self.registry = registry
        
    def execute(self, function_call: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a function based on a function call
        
        Args:
            function_call: Function call specification from Azure OpenAI API
            
        Returns:
            Function result
        """
        # Extract function name and arguments
        function_name = function_call.get("name")
        arguments_str = function_call.get("arguments", "{}")
        
        # Parse arguments
        try:
            arguments = json.loads(arguments_str)
        except json.JSONDecodeError:
            return {
                "error": f"Invalid function arguments: {arguments_str}"
            }
        
        # Get the function
        func = self.registry.get_function(function_name)
        if not func:
            return {
                "error": f"Function '{function_name}' not found"
            }
        
        # Execute the function
        try:
            result = func(**arguments)
            return result
        except Exception as e:
            return {
                "error": f"Error executing function '{function_name}': {str(e)}"
            }
    
    def execute_from_agent_response(self, agent_response: Dict[str, Any]) -> Optional[List[Dict[str, Any]]]:
        """Execute a function based on an agent response
        
        Args:
            agent_response: Response from Azure OpenAI API
            
        Returns:
            List of function results or None if no function call
        """
        # Check if the response contains function calls in the new format
        if "choices" in agent_response and len(agent_response["choices"]) > 0:
            message = agent_response["choices"][0].get("message", {})
            
            # Check for tool_calls in the new API format
            tool_calls = message.get("tool_calls", [])
            if tool_calls:
                results = []
                for tool_call in tool_calls:
                    if tool_call.get("type") == "function":
                        function_call = tool_call.get("function", {})
                        result = self.execute(function_call)
                        results.append({
                            "tool_call_id": tool_call.get("id"),
                            "function_name": function_call.get("name"),
                            "result": result
                        })
                return results
            
            # Check for function_call in the older API format
            function_call = message.get("function_call")
            if function_call:
                result = self.execute(function_call)
                return [{
                    "function_name": function_call.get("name"),
                    "result": result
                }]
        
        return None
    
    def execute_semantic_kernel_function(self, orchestrator, skill_name: str, function_name: str, parameters: Dict[str, Any]) -> Any:
        """Execute a function using Semantic Kernel
        
        Args:
            orchestrator: Orchestrator with Semantic Kernel integration
            skill_name: Name of the skill
            function_name: Name of the function
            parameters: Function parameters
            
        Returns:
            Function result
        """
        if not hasattr(orchestrator, "execute_semantic_function"):
            return {
                "error": "Orchestrator does not support Semantic Kernel functions"
            }
        
        try:
            result = orchestrator.execute_semantic_function(skill_name, function_name, parameters)
            return result
        except Exception as e:
            return {
                "error": f"Error executing Semantic Kernel function '{skill_name}.{function_name}': {str(e)}"
            }
    
    def prepare_function_response_messages(self, function_results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Prepare messages to send back to the model after function execution
        
        Args:
            function_results: Results from function execution
            
        Returns:
            List of messages formatted for the model
        """
        messages = []
        
        for result in function_results:
            tool_call_id = result.get("tool_call_id")
            function_name = result.get("function_name")
            function_result = result.get("result", {})
            
            # Format the result as a string
            if isinstance(function_result, dict):
                result_content = json.dumps(function_result)
            else:
                result_content = str(function_result)
            
            # Create the message
            if tool_call_id:
                # For newer API format
                messages.append({
                    "role": "tool",
                    "tool_call_id": tool_call_id,
                    "name": function_name,
                    "content": result_content
                })
            else:
                # For older API format
                messages.append({
                    "role": "function",
                    "name": function_name,
                    "content": result_content
                })
        
        return messages