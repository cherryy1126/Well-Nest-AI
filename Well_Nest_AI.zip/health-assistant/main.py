import os
import sys
import asyncio
from pathlib import Path
from dotenv import load_dotenv
from utils.azure_ai_service import AzureAIAgentService
from utils.model_selector import ModelSelector
from function_calling.function_registry import FunctionRegistry
from function_calling.function_executor import FunctionExecutor
from process_framework.workflow_manager import WorkflowManager
from orchestrator.orchestrator_agent import OrchestratorAgent

# Import all agent classes
from agents.appointment_agent.appointment_agent import AppointmentAgent
from agents.care_coordination_agent.care_coordination_agent import CareCoordinationAgent
from agents.emergency_response_agent.emergency_response_agent import EmergencyResponseAgent
from agents.health_metrics_agent.health_metrics_agent import HealthMetricsAgent
from agents.medication_agent.medication_agent import MedicationAgent
from agents.mental_health_agent.mental_health_agent import MentalHealthAgent
from agents.nutrition_agent.nutrition_agent import NutritionAgent

# Renamed main() to setup_orchestrator()
# This function now does all the setup and returns the orchestrator
async def setup_orchestrator():
    """
    Initializes and configures all services, agents, and the main orchestrator.
    Returns:
        OrchestratorAgent: The fully configured orchestrator instance.
    """
    # Load environment variables
    load_dotenv()

    # --- Add project directory to Python path ---
    base_dir = Path(__file__).resolve().parent
    if str(base_dir) not in sys.path:
        sys.path.append(str(base_dir))
    
    # Initialize Azure AI Agent Service
    azure_service = AzureAIAgentService()
    
    # Initialize model selector
    model_selector = ModelSelector(
        default_model="gpt-4o-mini",
        advanced_model="gpt-5-chat"
    )
    
    # Initialize function registry
    function_registry = FunctionRegistry()
    
    # Initialize function executor
    function_executor = FunctionExecutor(function_registry)
    
    # Initialize workflow manager
    workflow_manager = WorkflowManager()
    
    # Initialize orchestrator
    orchestrator = OrchestratorAgent(
        azure_service=azure_service,
        model_selector=model_selector,
        function_registry=function_registry,
        workflow_manager=workflow_manager
    )
    
    # Set up data paths
    data_dir = base_dir / "data"
    
    # --- Initialize all agents with data_dir ---
    
    appointment_agent = AppointmentAgent(
        azure_service=azure_service,
        data_dir=data_dir
    )
    
    care_coordination_agent = CareCoordinationAgent(
        azure_service=azure_service,
        data_dir=data_dir
    )
    
    emergency_response_agent = EmergencyResponseAgent(
        azure_service=azure_service,
        data_dir=data_dir
    )
    
    health_metrics_agent = HealthMetricsAgent(
        azure_service=azure_service,
        data_dir=data_dir
    )
    
    medication_agent = MedicationAgent(
        azure_service=azure_service,
        data_dir=data_dir
    )
    
    mental_health_agent = MentalHealthAgent(
        azure_service=azure_service,
        data_dir=data_dir
    )
    
    nutrition_agent = NutritionAgent(
        azure_service=azure_service,
        data_dir=data_dir
    )
    
    # Register agents with the orchestrator
    orchestrator.register_agent(
        agent_id="appointment_agent",
        agent_name="Appointment Scheduler",
        agent_type="appointment",
        agent_instance=appointment_agent
    )
    
    orchestrator.register_agent(
        agent_id="care_coordination_agent",
        agent_name="Care Coordination Assistant",
        agent_type="care_coordination",
        agent_instance=care_coordination_agent
    )
    
    orchestrator.register_agent(
        agent_id="emergency_response_agent",
        agent_name="Emergency Response Assistant",
        agent_type="emergency",
        agent_instance=emergency_response_agent
    )
    
    orchestrator.register_agent(
        agent_id="health_metrics_agent",
        agent_name="Health Metrics Tracker",
        agent_type="health_monitoring",
        agent_instance=health_metrics_agent
    )
    
    orchestrator.register_agent(
        agent_id="medication_agent",
        agent_name="Medication Manager",
        agent_type="medication",
        agent_instance=medication_agent
    )
    
    orchestrator.register_agent(
        agent_id="mental_health_agent",
        agent_name="Mental Health Support",
        agent_type="mental_health",
        agent_instance=mental_health_agent
    )
    
    orchestrator.register_agent(
        agent_id="nutrition_agent",
        agent_name="Nutrition Advisor",
        agent_type="nutrition",
        agent_instance=nutrition_agent
    )
    
    # Initialize Semantic Kernel if available
    try:
        if orchestrator._sk_initialized:
            orchestrator.register_semantic_kernel_plugins([
                "appointment_skills",
                "care_coordination_skills",
                "emergency_skills",
                "health_metrics_skills",
                "medication_skills",
                "mental_health_skills",
                "nutrition_skills"
            ])
    except Exception as e:
        print(f"Note: Semantic Kernel initialization failed: {e}")
        print("The application will continue without Semantic Kernel capabilities.")
    
    # Return the configured orchestrator
    return orchestrator

# New async main function for CLI/API interfaces
async def main():
    """
    Main entry point for running the CLI or API interfaces.
    """
    # Get the configured orchestrator
    orchestrator = await setup_orchestrator()
    
    # Start the appropriate interface
    interface_type = os.getenv("INTERFACE_TYPE", "CLI").upper()
    
    if interface_type == "API":
        from ui.api_ui_agent import start_api
        print("Starting API interface...")
        await start_api(orchestrator)
    elif interface_type == "CLI":
        from ui.cli_ui_agent import start_cli
        print("Starting CLI interface...")
        await start_cli(orchestrator)
    else:
        print(f"Unknown INTERFACE_TYPE: '{interface_type}'. Defaulting to CLI.")
        from ui.cli_ui_agent import start_cli
        await start_cli(orchestrator)

if __name__ == "__main__":
    # This block now only runs the CLI or API.
    # Streamlit will be run via a separate file.
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nExiting application...")
        sys.exit(0)