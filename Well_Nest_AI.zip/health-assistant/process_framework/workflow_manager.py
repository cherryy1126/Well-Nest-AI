from typing import Dict, Any, List, Optional
import asyncio
from .workflow import Workflow, WorkflowStep, SemanticKernelStep

class WorkflowManager:
    """Manages multiple workflows and their execution"""
    
    def __init__(self):
        """Initialize the workflow manager"""
        self.workflows: Dict[str, Workflow] = {}
        self.active_workflows: Dict[str, Dict[str, Any]] = {}
        
    def register_workflow(self, workflow: Workflow) -> None:
        """Register a workflow with the manager
        
        Args:
            workflow: Workflow to register
        """
        self.workflows[workflow.name] = workflow
        
    def start_workflow(self, workflow_name: str, context: Dict[str, Any] = None) -> str:
        """Start a new workflow instance
        
        Args:
            workflow_name: Name of the workflow to start
            context: Initial context
            
        Returns:
            Workflow instance ID
        """
        if workflow_name not in self.workflows:
            raise ValueError(f"Workflow '{workflow_name}' not registered")
            
        # Generate a unique ID for this workflow instance
        import uuid
        instance_id = str(uuid.uuid4())
        
        # Initialize context if not provided
        if context is None:
            context = {}
            
        # Add instance metadata
        context["workflow_instance_id"] = instance_id
        
        # Store the active workflow
        self.active_workflows[instance_id] = {
            "workflow_name": workflow_name,
            "context": context,
            "status": "running"
        }
        
        return instance_id
    
    async def execute_workflow(self, instance_id: str) -> Dict[str, Any]:
        """Execute a workflow instance to completion
        
        Args:
            instance_id: ID of the workflow instance
            
        Returns:
            Final workflow context
        """
        if instance_id not in self.active_workflows:
            raise ValueError(f"Workflow instance '{instance_id}' not found")
            
        instance = self.active_workflows[instance_id]
        workflow = self.workflows[instance["workflow_name"]]
        
        try:
            # Execute the workflow
            result = await workflow.execute(instance["context"])
            
            # Update the instance status
            instance["status"] = "completed"
            instance["context"] = result
            
            return result
        except Exception as e:
            # Update the instance status on error
            instance["status"] = "failed"
            instance["error"] = str(e)
            raise
    
    def get_workflow_status(self, instance_id: str) -> Dict[str, Any]:
        """Get the status of a workflow instance
        
        Args:
            instance_id: ID of the workflow instance
            
        Returns:
            Workflow instance status
        """
        if instance_id not in self.active_workflows:
            raise ValueError(f"Workflow instance '{instance_id}' not found")
            
        return self.active_workflows[instance_id]
    
    def create_semantic_kernel_workflow(self, 
                                          name: str, 
                                          description: str, 
                                          steps: List[Dict[str, Any]]) -> Workflow:
        """Create a workflow using Semantic Kernel functions
        
        Args:
            name: Name of the workflow
            description: Description of the workflow
            steps: List of step definitions
            
        Returns:
            Created workflow
        """
        workflow = Workflow(name, description)
        
        for i, step_def in enumerate(steps):
            step = SemanticKernelStep(
                name=step_def["name"],
                skill_name=step_def["skill_name"],
                function_name=step_def["function_name"],
                parameter_mapping=step_def["parameter_mapping"],
                next_steps=step_def.get("next_steps")
            )
            
            workflow.add_step(step, is_start=(i == 0))
            
        return workflow