# process_framework/__init__.py

"""
Process framework for deterministic agent collaboration in the Health and Wellness Assistant.

This package provides the infrastructure for defining and executing workflows
that coordinate multiple agents in a deterministic manner. It supports both
standard Python functions and Semantic Kernel functions as workflow steps.
"""

from .workflow import Workflow, WorkflowStep, SemanticKernelStep
from .workflow_manager import WorkflowManager

__all__ = ['Workflow', 'WorkflowStep', 'SemanticKernelStep', 'WorkflowManager']
