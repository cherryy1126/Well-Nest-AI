from typing import Dict, Any, List, Callable, Optional, Union, Awaitable
import asyncio

class WorkflowStep:
    """Represents a single step in a workflow"""
    
    def __init__(self, 
                 name: str, 
                 agent_id: str, 
                 action: Callable[[Dict[str, Any]], Any],
                 next_steps: Dict[str, str] = None,
                 is_async: bool = False):
        """Initialize a workflow step
        
        Args:
            name: Name of the step
            agent_id: ID of the agent to execute this step
            action: Function to execute for this step
            next_steps: Mapping of conditions to next step names
            is_async: Whether the action is an async function
        """
        self.name = name
        self.agent_id = agent_id
        self.action = action
        self.next_steps = next_steps or {"default": None}
        self.is_async = is_async
        
    async def execute(self, context: Dict[str, Any]) -> Optional[str]:
        """Execute this step and determine the next step
        
        Args:
            context: Workflow context
            
        Returns:
            Name of the next step or None if workflow should end
        """
        # Execute the action and store the result in context
        if self.is_async:
            result = await self.action(context)
        else:
            # If it's a synchronous function, run it directly or in a thread pool for CPU-bound operations
            if asyncio.get_event_loop().is_running():
                result = await asyncio.get_event_loop().run_in_executor(None, self.action, context)
            else:
                result = self.action(context)
                
        context["last_result"] = result
        context["last_step"] = self.name
        
        # Determine the next step based on conditions
        for condition, next_step in self.next_steps.items():
            if condition == "default":
                return next_step
            
            # Evaluate the condition using the result and context
            try:
                # Create a safe evaluation environment
                eval_globals = {"result": result, "context": context}
                if eval(condition, eval_globals):
                    return next_step
            except Exception as e:
                print(f"Error evaluating condition '{condition}': {e}")
                
        # If no condition matches, use the default
        return self.next_steps.get("default")

class SemanticKernelStep(WorkflowStep):
    """A workflow step that uses Semantic Kernel for execution"""
    
    def __init__(self,
                 name: str,
                 skill_name: str,
                 function_name: str,
                 parameter_mapping: Dict[str, str],
                 next_steps: Dict[str, str] = None):
        """Initialize a Semantic Kernel workflow step
        
        Args:
            name: Name of the step
            skill_name: Name of the Semantic Kernel skill
            function_name: Name of the Semantic Kernel function
            parameter_mapping: Mapping of context keys to function parameters
            next_steps: Mapping of conditions to next step names
        """
        # Create an action that will execute the Semantic Kernel function
        async def sk_action(context: Dict[str, Any]) -> Any:
            if "orchestrator" not in context:
                raise ValueError("Orchestrator not found in context")
                
            orchestrator = context["orchestrator"]
            if not hasattr(orchestrator, "execute_semantic_function"):
                raise ValueError("Orchestrator does not support Semantic Kernel functions")
                
            # Map parameters from context
            parameters = {}
            for param_name, context_key in parameter_mapping.items():
                if context_key in context:
                    parameters[param_name] = context[context_key]
                    
            # Execute the function
            # FIX: Added 'await' as execute_semantic_function is now async
            result = await orchestrator.execute_semantic_function(skill_name, function_name, parameters)
            return result
            
        # Initialize with the created action
        super().__init__(name, "semantic_kernel", sk_action, next_steps, is_async=True)
        self.skill_name = skill_name
        self.function_name = function_name
        self.parameter_mapping = parameter_mapping

class Workflow:
    """Represents a complete workflow with multiple steps"""
    
    def __init__(self, name: str, description: str = ""):
        """Initialize a workflow
        
        Args:
            name: Name of the workflow
            description: Description of the workflow
        """
        self.name = name
        self.description = description
        self.steps: Dict[str, WorkflowStep] = {}
        self.start_step: Optional[str] = None
        
    def add_step(self, step: WorkflowStep, is_start: bool = False) -> None:
        """Add a step to the workflow
        
        Args:
            step: Step to add
            is_start: Whether this is the starting step
        """
        self.steps[step.name] = step
        if is_start:
            self.start_step = step.name
            
    async def execute(self, context: Dict[str, Any] = None) -> Dict[str, Any]:
        """Execute the workflow from start to finish
        
        Args:
            context: Initial context (will be created if None)
            
        Returns:
            Final workflow context
        """
        if not self.start_step:
            raise ValueError("Workflow has no start step")
            
        # Initialize context if not provided
        if context is None:
            context = {}
            
        # Add workflow metadata to context
        context["workflow_name"] = self.name
        context["workflow_steps_executed"] = []
        
        # Execute steps until we reach the end
        current_step_name = self.start_step
        while current_step_name:
            if current_step_name not in self.steps:
                raise ValueError(f"Step '{current_step_name}' not found in workflow")
                
            # Get and execute the current step
            current_step = self.steps[current_step_name]
            context["workflow_steps_executed"].append(current_step_name)
            
            # Execute the step and get the next step
            next_step_name = await current_step.execute(context)
            current_step_name = next_step_name
            
        return context