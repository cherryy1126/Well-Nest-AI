# Health and Wellness Assistant

## Project Overview

The Health and Wellness Assistant is a multi-agent system designed to help users manage their health-related tasks, from scheduling appointments to monitoring health metrics and managing medications. This multi-agent system leverages Azure AI Agent Service and Semantic Kernel integration for intelligent agent capabilities and implements deterministic agent collaboration through a process framework.

## Explanation
Our project leverages Azure AI Agent Service, OpenAI function calling, Semantic Kernel integration and a deterministic process framework to create a robust health and wellness assistant. The core functionality includes:
- **Multi-Agent Collaboration**: Domain-specific agents working together to address various health needs
- **Deterministic Workflows**: Structured processes ensuring reliable and predictable agent interactions
- **Function Calling Framework**: Enabling agents to perform concrete actions like scheduling appointments
- **Comprehensive Health Management**: Covering nutrition, medication, appointments, health metrics, mental health, and emergency response

## Intent
The primary intent of our project is to demonstrate how multiple AI agents can collaborate deterministically to provide comprehensive health and wellness support. We aim to create a system that can reliably assist users with their health management needs while maintaining data privacy and ensuring appropriate coordination between different health domains.

 
Our solution is designed to be used by individuals managing their personal health or caregivers supporting others. It can be applied in scenarios such as:
- **Chronic Disease Management**: Helping patients track medications, appointments, and health metrics for conditions like diabetes or hypertension
- **Preventive Health**: Supporting users in maintaining healthy habits through nutrition guidance and regular health check-ups
- **Care Coordination**: Assisting elderly individuals or their caregivers in managing complex healthcare needs across multiple providers



## Implementation
Our Health and Wellness Assistant is implemented as a modular system with several key components:

## Directory Structure

### Root Files

| File | Description |
|------|-------------|
| `.gitignore` | Specifies files to exclude from version control (env files, pycache, etc.) |
| `.env` | Contains environment variables including Azure OpenAI API credentials |
| `README.md` | Project documentation with setup instructions and overview |
| `requirements.txt` | Lists project dependencies (openai, requests, tiktoken, etc.) |
| `main.py` | Entry point for the application that initializes and connects all components |


## Core Components

### 1. Domain-Specific Agents (`/agents/`)

Each agent specializes in a specific health domain and implements the logic for handling related tasks:

| Agent | Purpose |
|-------|---------|
| `appointment_agent` | Manages healthcare appointment scheduling |
| `care_coordination_agent` | Coordinates care across multiple providers |
| `emergency_response_agent` | Handles urgent health situations and alerts |
| `health_metrics_agent` | Monitors and analyzes health metrics from devices |
| `medication_agent` | Handles medication reminders and adherence tracking |
| `mental_health_agent` | Provides mental health support and monitoring |
| `nutrition_agent` | Manages dietary recommendations and meal planning |

### 2. Azure OpenAI Integration (`/utils/`)

Provides utilities for interacting with Azure OpenAI API:

| File | Purpose |
|------|---------|
| `azure_ai_service.py` | Client for Azure OpenAI API interactions |
| `model_selector.py` | Selects appropriate models based on context and complexity |

### 3. Function Calling Framework (`/function_calling/`)

Implements the core interaction pattern for agents to call functions:

| File | Purpose |
|------|---------|
| `function_registry.py` | Registers functions that can be called by agents and generates OpenAI-compatible schemas |
| `function_executor.py` | Executes functions based on agent requests and handles results |

### 4. Process Framework for Deterministic Agent Collaboration (`/process_framework/`)

Enables structured, deterministic workflows for multi-agent collaboration:

| File | Purpose |
|------|---------|
| `workflow_manager.py` | Manages multiple workflows and their execution states |
| `workflow.py` | Manages orchestrator and agents instructions + workflows |

### 5. Orchestration (`/orchestrator/`)

Coordinates the interactions between different agents:

| File | Purpose |
|------|---------|
| `orchestrator_agent.py` | Routes requests to appropriate agents, manages workflows, and handles function calls |

### 6. User Interfaces (`/ui/`)

Provides different interfaces for interacting with the system:

| File | Purpose |
|------|---------|
| `cli_ui_agent.py` | Command-line interface for the assistant |
| `api_ui_agent.py` | FastAPI-based web API for integration with other systems |

### 7. Semantic Kernel Integration (`/semantic_kernel/`)

Optional integration with Semantic Kernel for enhanced capabilities:

| File | Purpose |
|------|---------|
| `sk_config.py` | Configuration for Semantic Kernel |
| `*_skills.py` | Domain-specific skills for Semantic Kernel |

### 8. Data Files (`/data/`)

Contains structured data for the application:

| File | Purpose |
|------|---------|
| `Appointments.json` | Appointment data and scheduling information |
| `Care Coordination Data.json` | Care coordination across providers |
| `Health Metrics.json` | User health measurements and tracking |
| `Healthcare Providers.json` | Provider information and specialties |
| `Medications.json` | Medication information and schedules |
| `Mental Health Data.json` | Mental health tracking and resources |
| `Nutrition Data.json` | Nutritional information and meal plans |
| `User Profiles.json` | User profile information |

## Key Integration Points

1. **Agent Orchestration**: The orchestrator routes requests to appropriate domain agents based on the user's needs and context.

2. **Function Calling**: Agents can call registered functions to perform actions like retrieving appointment information or booking appointments.

3. **Workflow Management**: Complex health tasks are broken down into workflows with defined steps and decision points.

4. **Azure OpenAI API**: Provides the intelligence for agents, enabling them to understand user requests and generate appropriate responses.

5. **Semantic Kernel (Optional)**: Enhances capabilities with structured prompting and specialized skills when available.

## Implementation Approach

The system follows a modular design where:

- Each domain agent focuses on a specific health domain
- The orchestrator manages the flow of information between agents
- The process framework ensures deterministic agent collaboration
- The function calling framework enables agents to perform actions
- Data files provide structured information for the agents to work with

This architecture allows for:

- Independent development and testing of each component
- Easy addition of new agents and capabilities
- Deterministic behavior in multi-agent scenarios
- Integration with external healthcare systems

By implementing this structure, the Health and Wellness Assistant provides a comprehensive solution for managing health-related tasks while leveraging the power of Azure AI Agent Service for intelligent interactions.

## Getting Started

### Prerequisites

- Python 3.8 or higher
- Azure OpenAI API access
- Azure AI Agent Service access

### Installation

1. Clone the repository:
   
git clone 




3. Install dependencies:
   
pip install -r requirements.txt


5. Set up environment variables:
   
cp .env.example .env

Edit .env with your Azure OpenAI credentials


4. Run the application:
   
python main.py


