# health-assistant/orchestrator/__init__.py
# Orchestrator module for the Health Assistant application.
# This module provides orchestration capabilities for routing requests between different specialized agents, managing workflows, and coordinating interactions

from .orchestrator_agent import OrchestratorAgent

__all__ = ['OrchestratorAgent']


# Module metadata
__author__ = 'Health Assistant Team'
__description__ = 'Orchestration module for the Health Assistant application'
