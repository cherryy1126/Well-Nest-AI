import json
import time
import asyncio
import importlib # Added for dynamic plugin loading
from typing import Dict, Any, List, Optional, Tuple
from utils.azure_ai_service import AzureAIAgentService
from utils.model_selector import ModelSelector
from function_calling.function_registry import FunctionRegistry
from function_calling.function_executor import FunctionExecutor
from process_framework.workflow_manager import WorkflowManager

class OrchestratorAgent:
    """Orchestrates the interactions between different agents"""
    
    def __init__(self, 
                 azure_service: AzureAIAgentService,
                 model_selector: ModelSelector = None,
                 function_registry: FunctionRegistry = None,
                 workflow_manager: WorkflowManager = None):
        """Initialize the orchestrator agent"""
        self.azure_service = azure_service
        self.model_selector = model_selector
        self.function_registry = function_registry or FunctionRegistry()
        self.function_executor = FunctionExecutor(self.function_registry)
        self.workflow_manager = workflow_manager or WorkflowManager()
        
        # Agent registry
        self.agents = {}
        
        # User context storage
        self.user_contexts = {}
        self.agent_history = {} # NEW: Store agent-specific conversation history
        
        # Semantic Kernel integration
        self._sk_kernel = None
        self._sk_agent_system = None
        self._sk_initialized = False
        self._sk_group_chats = {}
        
        # Initialize Semantic Kernel
        self.initialize_semantic_kernel()
    
    def register_agent(self, agent_id: str, agent_name: str, agent_type: str, agent_instance=None) -> None:
        """Register an agent with the orchestrator"""
        self.agents[agent_id] = {
            "name": agent_name,
            "type": agent_type,
            "instance": agent_instance
        }
    
    async def route_request(self, 
                             user_id: str, 
                             message: str, 
                             conversation_id: Optional[str] = None,
                             context_override: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Route a request to the appropriate agent"""
        # Get or initialize user context
        if user_id not in self.user_contexts:
            self.user_contexts[user_id] = {
                "conversation_complexity": 0,
                "recent_queries": [],
                "recent_responses": [],
                "user_tier": "standard",
                "total_tokens": 0,
                "total_cost": 0.0,
                "last_reset": time.time(),
                "advanced_model_unavailable": False
            }
            self.agent_history[user_id] = {} # NEW: Initialize agent history store for new user
        
        user_context = self.user_contexts[user_id]
        
        # Apply context override if provided
        if context_override:
            user_context.update(context_override)
        
        # Check if we need to reset daily stats
        if time.time() - user_context.get("last_reset", 0) > 86400:
            user_context["daily_tokens"] = 0
            user_context["daily_cost"] = 0.0
            user_context["last_reset"] = time.time()
            user_context["advanced_model_unavailable"] = False
        
        # Get usage stats to check cost threshold
        if self.azure_service and hasattr(self.azure_service, 'get_usage_stats'):
            usage_stats = self.azure_service.get_usage_stats()
            user_context["approaching_cost_threshold"] = usage_stats.get("approaching_threshold", False)
        
        # Store the current query
        user_context["recent_queries"].append(message)
        if len(user_context["recent_queries"]) > 5:
            user_context["recent_queries"].pop(0)
        
        # Check if we should use multi-agent system for this request
        if self._should_use_multi_agent(message, user_context):
            try:
                return await self.process_with_multi_agent(user_id, message, conversation_id, user_context)
            except Exception as e:
                print(f"Error using multi-agent system: {e}. Falling back to standard processing.")
        
        # Check if we should use Semantic Kernel for this request
        if self._should_use_semantic_kernel(message, user_context):
            try:
                return await self.process_with_semantic_kernel(user_id, message, user_context)
            except Exception as e:
                print(f"Error using Semantic Kernel: {e}. Falling back to standard processing.")
        
        # --- FIX: Call the new async _determine_agent ---
        # Standard processing with single agent
        agent_id = await self._determine_agent(message, user_context)
        # --- END FIX ---
        
        # --- NEW: Prepare agent-specific history ---
        if agent_id not in self.agent_history[user_id]:
            self.agent_history[user_id][agent_id] = []
        
        agent_specific_history = self.agent_history[user_id][agent_id]
        agent_specific_history.append({"role": "user", "content": message})
        
        # Pass this history to the agent via the context
        user_context["conversation_history"] = agent_specific_history
        # --- END NEW ---

        user_context["agent_id"] = agent_id
        user_context["user_id"] = user_id
        if conversation_id:
            user_context["conversation_id"] = conversation_id
        
        # Select model
        if self.model_selector:
            model = self.model_selector.select_model_for_agent(agent_id, message, user_context)
        else:
            # FIX: Replaced 'gpt-35-turbo' with 'gpt-4o-mini'
            model = "gpt-4o-mini" if user_context.get("conversation_complexity", 0) > 5 else "gpt-4o-mini"
        
        # Get agent instance
        agent_info = self.agents.get(agent_id, {})
        agent_instance = agent_info.get("instance")
        
        # Invoke agent
        start_time = time.time()
        try:
            if agent_instance and hasattr(agent_instance, "process_request"):
                # The agent will now receive the history in the context
                response = await agent_instance.process_request(user_id, message, user_context)
            else:
                response = await self.azure_service.invoke_agent(
                    agent_id=agent_id,
                    message=message,
                    conversation_id=conversation_id,
                    context=user_context
                )
        except Exception as e:
            if self.model_selector and model == self.model_selector.advanced_model and ("503" in str(e) or "Service Unavailable" in str(e)):
                user_context["advanced_model_unavailable"] = True
                print(f"Marking {model} as unavailable due to service error")
                # FIX: Replaced 'gpt-35-turbo' with 'gpt-4o-mini'
                model = self.model_selector.default_model if self.model_selector else "gpt-4o-mini"
                
                if agent_instance and hasattr(agent_instance, "process_request"):
                    user_context["model"] = model
                    response = await agent_instance.process_request(user_id, message, user_context)
                else:
                    response = await self.azure_service.invoke_agent(
                        agent_id=agent_id,
                        message=message,
                        conversation_id=conversation_id,
                        context=user_context
                    )
            else:
                raise
        
        elapsed_time = time.time() - start_time
        
        # Process function calls if present
        function_results = None
        if (response.get("choices") and 
            response["choices"][0].get("message") and 
            (response["choices"][0]["message"].get("function_call") or 
             response["choices"][0]["message"].get("tool_calls"))):
    
            function_results = self.function_executor.execute_from_agent_response(response)
            if function_results:
                response["function_results"] = function_results
                function_messages = self.function_executor.prepare_function_response_messages(function_results)
    
                if agent_instance and hasattr(agent_instance, "process_request"):
                    updated_context = user_context.copy()
                    updated_context["function_results"] = function_results
                    updated_context["function_messages"] = function_messages
                    follow_up_response = await agent_instance.process_request(
                        user_id=user_id,
                        message="Process function results",
                        context=updated_context
                    )
                    response["follow_up_response"] = follow_up_response
                else:
                    system_message = "You are a healthcare assistant helping with a multi-step task."
                    follow_up_messages = [
                        {"role": "system", "content": system_message},
                        {"role": "user", "content": message}
                    ]
                    if "choices" in response and response["choices"][0].get("message"):
                        follow_up_messages.append({
                            "role": "assistant",
                            "content": None,
                            "function_call": response["choices"][0]["message"].get("function_call"),
                            "tool_calls": response["choices"][0]["message"].get("tool_calls")
                        })
                    follow_up_messages.extend(function_messages)
                    follow_up_response = await self.azure_service.invoke_model(
                        messages=follow_up_messages,
                        deployment_id=model
                    )
                    response["follow_up_response"] = follow_up_response
        
        # Store response for context
        if "message" in response:
            user_context["recent_responses"].append(response["message"])
            if len(user_context["recent_responses"]) > 5:
                user_context["recent_responses"].pop(0)
        
        # Update context based on response
        self._update_context(user_id, message, response, model, elapsed_time)
        
        # Add metadata
        response["_metadata"] = {
            "agent_id": agent_id,
            "model": model,
            "elapsed_time": elapsed_time,
            "conversation_complexity": user_context["conversation_complexity"]
        }
        
        return response
    
    async def execute_workflow(self, workflow_name: str, context: Dict[str, Any] = None) -> Dict[str, Any]:
        """Execute a workflow"""
        instance_id = self.workflow_manager.start_workflow(workflow_name, context or {})
        result = await self.workflow_manager.execute_workflow(instance_id)
        return result
    
    # --- FIX: Replaced entire _determine_agent method with an LLM-powered router ---
    async def _determine_agent(self, message: str, context: Dict[str, Any]) -> str:
        """Determine which agent should handle a request using an LLM."""
        
        # 1. Check for a follow-up conversation (context priority)
        message_lower = message.lower()
        
        # Define keywords that signal the user wants to *switch* topics.
        topic_switch_keywords = [
            "emergency", "urgent", "chest pain",
            "appointment", "schedule", "book", "doctor",
            "medication", "drug", "prescription",
            "metric", "weight", "blood pressure", "track",
            "mental", "anxiety", "stress", "mood",
            "diet", "nutrition", "food",
            "care", "coordination", "specialist"
        ]
        
        has_topic_switch = any(keyword in message_lower for keyword in topic_switch_keywords)

        # If an agent is in context AND the user is NOT trying to switch topics,
        # stay with the current agent.
        if "agent_id" in context and context["agent_id"] in self.agents and not has_topic_switch:
            print(f"--- Routing: Continuing conversation with {context['agent_id']} ---")
            return context["agent_id"]

        # 2. If it's a new topic or a switch, use the LLM router.
        print(f"--- Routing: New topic or switch detected, using LLM router for message: '{message}' ---")

        # Build the prompt for the router
        agent_list = ""
        for agent_id, info in self.agents.items():
            agent_list += f"- agent_id: \"{agent_id}\", name: \"{info['name']}\", type: \"{info['type']}\"\n"

        system_message = f"""
        You are an expert router for a healthcare AI system.
        Your job is to route a user's request to the correct specialist agent.
        You must respond with ONLY the 'agent_id' of the chosen agent and nothing else.

        Available agents:
        {agent_list}

        Routing Guide:
        - Use 'emergency_response_agent' for anything urgent or life-threatening (chest pain, difficulty breathing, etc.).
        - Use 'appointment_agent' for booking, scheduling, or checking appointments.
        - Use 'medication_agent' for questions about drugs, prescriptions, or side effects.
        - Use 'health_metrics_agent' for logging or asking about symptoms, vitals, or metrics (like "fever", "blood pressure", "weight").
        - Use 'mental_health_agent' for topics of stress, anxiety, mood, or feeling down.
        - Use 'nutrition_agent' for diet, food, or meal planning.
        - Use 'care_coordination_agent' for complex topics involving multiple doctors or specialists.
        - If the user is just saying hello or the topic is unclear, default to 'health_metrics_agent'.

        User request: "{message}"
        Chosen agent_id:
        """
        
        # Use the azure_service to make the call
        try:
            response = await self.azure_service.invoke_model(
                messages=[{"role": "system", "content": system_message}],
                deployment_id="gpt-4o-mini"
            )
            
            # The response *should* be just the agent_id
            chosen_agent_id = response["choices"][0]["message"]["content"].strip().replace('"', '')
            
            if chosen_agent_id in self.agents:
                print(f"--- Routing: LLM chose {chosen_agent_id} ---")
                return chosen_agent_id
            else:
                print(f"--- Routing: LLM chose an invalid agent: '{chosen_agent_id}'. Defaulting to health_metrics_agent. ---")
                return "health_metrics_agent" # Safe default

        except Exception as e:
            print(f"--- Routing: LLM router failed: {e}. Defaulting to health_metrics_agent. ---")
            # Fallback to a "safe" default
            return "health_metrics_agent"
    # --- END FIX ---
    
    def _update_context(self, user_id: str, message: str, response: Dict[str, Any], model: str, elapsed_time: float) -> None:
        """Update user context based on the interaction"""
        user_context = self.user_contexts[user_id]
        
        # --- NEW: Update agent-specific history ---
        # Use agent_id from metadata if available, otherwise from response root
        agent_id = response.get("_metadata", {}).get("agent_id") or response.get("agent_id")
        response_message = response.get("message")
        
        if agent_id and response_message and user_id in self.agent_history:
            if agent_id not in self.agent_history[user_id]:
                self.agent_history[user_id][agent_id] = []
            
            # Add the assistant's response to the history
            self.agent_history[user_id][agent_id].append({"role": "assistant", "content": response_message})
            
            # Prune history to keep it manageable (e.g., last 10 turns = 20 messages)
            if len(self.agent_history[user_id][agent_id]) > 20:
                    self.agent_history[user_id][agent_id] = self.agent_history[user_id][agent_id][-20:]
        # --- END NEW ---
        
        # Update conversation complexity based on token usage
        usage = response.get("usage", {})
        tokens = usage.get("total_tokens", 0)
        
        # --- FIX: Initialize total_cost to 0.0 ---
        total_cost = 0.0
        # --- END FIX ---

        # Update token counts
        user_context["total_tokens"] = user_context.get("total_tokens", 0) + tokens
        user_context["daily_tokens"] = user_context.get("daily_tokens", 0) + tokens
        
        # Update cost tracking if we have model info
        if self.azure_service and hasattr(self.azure_service, 'models') and model in self.azure_service.models:
            model_info = self.azure_service.models.get(model, {})
            input_cost = (usage.get("prompt_tokens", 0) / 1000) * model_info.get("cost_per_1k_input_tokens", 0)
            output_cost = (usage.get("completion_tokens", 0) / 1000) * model_info.get("cost_per_1k_output_tokens", 0)
            total_cost = input_cost + output_cost # total_cost is re-assigned here if info exists
            
            user_context["total_cost"] = user_context.get("total_cost", 0.0) + total_cost
            user_context["daily_cost"] = user_context.get("daily_cost", 0.0) + total_cost
        
        # Update conversation complexity
        complexity_increase = 0
        if tokens > 200:
            complexity_increase += 1
        if len(message) > 100:
            complexity_increase += 1
        
        # More complex if using advanced model
        if self.model_selector and model == self.model_selector.advanced_model:
            complexity_increase += 1

        user_context["conversation_complexity"] = min(10, user_context.get("conversation_complexity", 0) + complexity_increase)
        
        # Track model usage
        if "model_usage" not in user_context:
            user_context["model_usage"] = {}
            
        if model not in user_context["model_usage"]:
            user_context["model_usage"][model] = {"calls": 0, "tokens": 0, "cost": 0.0}
            
        user_context["model_usage"][model]["calls"] = user_context["model_usage"][model].get("calls", 0) + 1
        user_context["model_usage"][model]["tokens"] = user_context["model_usage"][model].get("tokens", 0) + tokens
        user_context["model_usage"][model]["cost"] = user_context["model_usage"][model].get("cost", 0.0) + total_cost

        # Track agent usage
        if "agent_usage" not in user_context:
            user_context["agent_usage"] = {}
            
        agent_id = response.get("agent_id")
        if agent_id and agent_id not in user_context["agent_usage"]:
            user_context["agent_usage"][agent_id] = {"calls": 0, "tokens": 0, "cost": 0.0}
            
        if agent_id:
            user_context["agent_usage"][agent_id]["calls"] = user_context["agent_usage"][agent_id].get("calls", 0) + 1
            user_context["agent_usage"][agent_id]["tokens"] = user_context["agent_usage"][agent_id].get("tokens", 0) + tokens
            user_context["agent_usage"][agent_id]["cost"] = user_context["agent_usage"][agent_id].get("cost", 0.0) + total_cost
    
    def get_user_context(self, user_id: str) -> Dict[str, Any]:
        """Get the context for a specific user"""
        return self.user_contexts.get(user_id, {})
    
    def update_user_context(self, user_id: str, updates: Dict[str, Any]) -> None:
        """Update a user's context with new values"""
        if user_id not in self.user_contexts:
            self.user_contexts[user_id] = {}
            
        self.user_contexts[user_id].update(updates)
    
    def get_usage_stats(self) -> Dict[str, Any]:
        """Get overall usage statistics"""
        # Calculate total tokens and cost across all users
        total_tokens = sum(context.get("total_tokens", 0) for context in self.user_contexts.values())
        total_cost = sum(context.get("total_cost", 0.0) for context in self.user_contexts.values())
        
        # Aggregate model usage across all users
        model_usage = {}
        for context in self.user_contexts.values():
            for model, stats in context.get("model_usage", {}).items():
                if model not in model_usage:
                    model_usage[model] = {"calls": 0, "tokens": 0, "cost": 0.0}
                
                model_usage[model]["calls"] += stats.get("calls", 0)
                model_usage[model]["tokens"] += stats.get("tokens", 0)
                model_usage[model]["cost"] += stats.get("cost", 0.0)
        
        # Aggregate agent usage across all users
        agent_usage = {}
        for context in self.user_contexts.values():
            for agent_id, stats in context.get("agent_usage", {}).items():
                if agent_id not in agent_usage:
                    agent_usage[agent_id] = {"calls": 0, "tokens": 0, "cost": 0.0}
                
                agent_usage[agent_id]["calls"] += stats.get("calls", 0)
                agent_usage[agent_id]["tokens"] += stats.get("tokens", 0)
                agent_usage[agent_id]["cost"] += stats.get("cost", 0.0)
        
        # Get service-level stats
        service_stats = self.azure_service.get_usage_stats() if self.azure_service else {}
        
        return {
            "total_users": len(self.user_contexts),
            "total_tokens": total_tokens,
            "total_cost": total_cost,
            "total_calls": sum(stats["calls"] for stats in model_usage.values()) if model_usage else 0,
            "model_usage": model_usage,
            "agent_usage": agent_usage,
            "approaching_threshold": service_stats.get("approaching_threshold", False),
            "daily_cost": service_stats.get("daily_cost", 0.0),
            "cost_threshold": service_stats.get("cost_threshold", 5.0)
        }
    
    def reset_usage_stats(self) -> None:
        """Reset usage statistics for all users"""
        for user_id in self.user_contexts:
            self.user_contexts[user_id]["total_tokens"] = 0
            self.user_contexts[user_id]["total_cost"] = 0.0
            self.user_contexts[user_id]["daily_tokens"] = 0
            self.user_contexts[user_id]["daily_cost"] = 0.0
            self.user_contexts[user_id]["model_usage"] = {}
            self.user_contexts[user_id]["agent_usage"] = {}
            self.user_contexts[user_id]["last_reset"] = time.time()
            
        # Also reset the service-level stats
        if self.azure_service and hasattr(self.azure_service, 'reset_usage_stats'):
            self.azure_service.reset_usage_stats()
    
    def get_agent_info(self, agent_id: str = None) -> Dict[str, Any]:
        """Get information about registered agents"""
        if agent_id:
            return self.agents.get(agent_id, {})
        else:
            return self.agents
    
    def get_conversation_history(self, user_id: str, max_entries: int = 5) -> List[Dict[str, str]]:
        """Get conversation history for a user"""
        user_context = self.user_contexts.get(user_id, {})
        queries = user_context.get("recent_queries", [])
        responses = user_context.get("recent_responses", [])
        
        # Pair queries and responses
        history = []
        for i, (query, response) in enumerate(zip(queries, responses)):
            history.append({
                "turn": i + 1,
                "user_message": query,
                "assistant_response": response
            })
        
        # Return the most recent entries
        return history[-max_entries:]
    
    # --- Semantic Kernel Integration Methods ---
    
    def initialize_semantic_kernel(self):
        """Initialize Semantic Kernel and multi-agent system"""
        try:
            # Initialize the kernel
            import semantic_kernel as sk
            import os
            
            self._sk_kernel = sk.Kernel()
            
            # Get credentials from environment
            api_key = os.environ.get("AZURE_OPENAI_API_KEY")
            endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT")
            # FIX: Replaced 'gpt-35-turbo' with 'gpt-4o-mini'
            deployment = os.environ.get("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o-mini")
            api_version = os.environ.get("AZURE_OPENAI_API_VERSION", "2023-12-01-preview")
            
            # Add Azure OpenAI service to the kernel
            from semantic_kernel.connectors.ai.open_ai import AzureChatCompletion
            
            chat_completion = AzureChatCompletion(
                deployment_name=deployment,
                api_key=api_key,
                endpoint=endpoint, # FIX: Use endpoint, not base_url
                api_version=api_version
            )
            
            self._sk_kernel.add_service(chat_completion)
            
            self._sk_agent_system = None
            
            self._sk_initialized = True
            print("Semantic Kernel initialized successfully")
            return True
        except ImportError:
            print("Semantic Kernel not installed. Skipping initialization.")
            self._sk_initialized = False
            return False
        except Exception as e:
            print(f"Error initializing Semantic Kernel: {e}")
            self._sk_initialized = False
            return False

    # FIX: Added the missing register_semantic_kernel_plugins method
    def register_semantic_kernel_plugins(self, plugin_names: List[str]):
        """Dynamically import and register Semantic Kernel plugins (skills)"""
        if not self._sk_initialized:
            print("Cannot register SK plugins: Semantic Kernel not initialized.")
            return

        for plugin_name in plugin_names:
            try:
                # Dynamically import the plugin module
                module_path = f"semantic_kernel.{plugin_name}"
                plugin_module = importlib.import_module(module_path)
                
                # Convention: Class name is CamelCase version of module name
                # e.g., "appointment_skills" -> "AppointmentSkills"
                class_name = "".join(word.capitalize() for word in plugin_name.split('_'))
                
                # Get the class from the module
                PluginClass = getattr(plugin_module, class_name)
                
                # Instantiate the plugin
                plugin_instance = PluginClass()
                
                # Register the plugin with the kernel
                self._sk_kernel.import_plugin_from_object(plugin_instance, plugin_name)
                print(f"Successfully registered SK plugin: {plugin_name}")
                
            except ImportError:
                print(f"Warning: Could not import SK plugin module: {module_path}")
            except AttributeError:
                print(f"Warning: Could not find class {class_name} in module {module_path}")
            except Exception as e:
                print(f"Error registering SK plugin {plugin_name}: {e}")

    def _should_use_semantic_kernel(self, message: str, context: Dict[str, Any]) -> bool:
        """Determine if a request should use Semantic Kernel instead of direct LLM calls"""
        # Check if explicitly requested
        if context.get("use_semantic_kernel", False):
            return True
        
        # Check if Semantic Kernel is initialized
        if not self._sk_initialized:
            return False
        
        # Define patterns that are good candidates for Semantic Kernel
        message_lower = message.lower()
        
        sk_patterns = {
            "appointment": ["schedule appointment", "book appointment", "doctor availability"],
            "medication": ["medication info", "drug interaction", "check medication"],
            "health_metrics": ["log metrics", "record blood pressure", "analyze metrics"],
            "nutrition": ["meal plan", "food interaction", "dietary plan"],
            "mental_health": ["stress management", "mood tracking", "mental wellness"]
        }
        
        # Check if any patterns match
        for domain, patterns in sk_patterns.items():
            if any(pattern in message_lower for pattern in patterns):
                return True
        
        # By default, don't use Semantic Kernel
        return False
    
    def _should_use_multi_agent(self, message: str, context: Dict[str, Any]) -> bool:
        """Determine if a request should use the multi-agent system"""
        # Check if explicitly requested
        if context.get("use_multi_agent", False):
            return True
        
        # Check if Semantic Kernel is initialized
        if not self._sk_initialized:
            return False
        
        # Define patterns that are good candidates for multi-agent collaboration
        message_lower = message.lower()
        
        # Complex healthcare scenarios that benefit from multiple specialists
        complex_patterns = [
            "medication and appointment",
            "diet and medication",
            "mental health and physical",
            "symptoms and schedule",
            "coordinate my care",
            "multiple doctors",
            "specialist referral",
            "treatment plan",
            "chronic condition",
            "multiple symptoms",
            "health history"
        ]
        
        # Check if any patterns match
        for pattern in complex_patterns:
            if pattern in message_lower:
                return True
        
        # Check message complexity - longer messages often involve multiple domains
        if len(message.split()) > 30:  # If message has more than 30 words
            domain_count = 0
            domains = ["medication", "appointment", "diet", "mental health", "blood pressure", "doctor", "specialist"]
            for domain in domains:
                if domain in message_lower:
                    domain_count += 1
            
            # Use multi-agent if multiple domains are mentioned in a long message
            if domain_count >= 2:
                return True
        
        # By default, don't use multi-agent system
        return False
    
    async def process_with_multi_agent(self, user_id: str, message: str, conversation_id=None, context=None):
        """Process a request using the multi-agent system"""
        if not self._sk_initialized:
            # Fallback to standard processing if Semantic Kernel is not initialized
            print("Semantic Kernel not initialized. Falling back to standard processing.")
            return await self.route_request(user_id, message, conversation_id, context)
        
        try:
            # Create a chat history
            from semantic_kernel.contents.chat_history import ChatHistory
            history = ChatHistory()
            
            # Add system message to explain the multi-agent concept
            history.add_system_message("""You are a healthcare assistant that coordinates multiple specialist agents.
            Based on the user's query, you'll determine which specialists to consult and synthesize their responses.
            Available specialists: General Practitioner, Medication Specialist, Appointment Scheduler, Mental Health Specialist, Nutritionist""")
            
            # Add the user message
            history.add_user_message(message)
            
            # Get the chat completion service
            from semantic_kernel.connectors.ai.chat_completion_client_base import ChatCompletionClientBase
            chat_completion = self._sk_kernel.get_service(type=ChatCompletionClientBase)
            
            # Create execution settings
            from semantic_kernel.connectors.ai.open_ai.prompt_execution_settings.azure_chat_prompt_execution_settings import (
                AzureChatPromptExecutionSettings,
            )
            execution_settings = AzureChatPromptExecutionSettings()
            
            # Get the response
            result = await chat_completion.get_chat_message_content(
                chat_history=history,
                settings=execution_settings,
                kernel=self._sk_kernel,
            )
            
            return {
                "agent_id": "multi_agent_system",
                "conversation_id": conversation_id,
                "message": str(result),
                "agents_involved": ["Semantic Kernel Multi-Agent System"]
            }
        except Exception as e:
            print(f"Error processing with multi-agent system: {e}")
            # Fallback to standard processing
            return await self.route_request(user_id, message, conversation_id, context)
    
    async def process_with_semantic_kernel(self, user_id: str, message: str, context=None):
        """Process a request using Semantic Kernel"""
        if not self._sk_initialized:
            raise ValueError("Semantic Kernel is not initialized")
        
        # Determine which skill and function to use
        system_message = """
        You are a healthcare assistant that helps route requests to the appropriate semantic function.
        Based on the user's message, determine which semantic function should handle this request.
        
        Available skills and functions:
        - appointment.schedule_appointment(date, time, provider, user_id)
        - appointment.get_upcoming_appointments(user_id)
        - medication.get_medication_info(medication)
        - medication.check_interactions(medications)
        - health_metrics.log_metrics(metrics)
        - health_metrics.analyze_metrics(metrics)
        - nutrition.generate_meal_plan(goal, restrictions)
        - mental_health.track_mood(user_id, mood, notes)
        
        Respond with a JSON object containing:
        {
            "skill": "skill_name",
            "function": "function_name",
            "parameters": {
                "param1": "value1",
                "param2": "value2"
            }
        }
        """
        
        # Use the Azure AI Service to determine the function to call
        # FIX: Replaced 'gpt-35-turbo' with 'gpt-4o-mini'
        response = await self.azure_service.invoke_model(
            messages=[
                {"role": "system", "content": system_message},
                {"role": "user", "content": message}
            ],
            deployment_id="gpt-4o-mini"
        )
        
        try:
            # Extract the function call from the response
            function_call_text = response["choices"][0]["message"]["content"]
            function_call = json.loads(function_call_text)
            
            # Execute the semantic function
            skill_name = function_call["skill"]
            function_name = function_call["function"]
            parameters = function_call["parameters"]
            
            # Add user_id to parameters if needed
            if "user_id" not in parameters and function_name in [
                "schedule_appointment", "get_upcoming_appointments", "track_mood"
            ]:
                parameters["user_id"] = user_id
            
            # Execute the function
            # FIX: Await the async execute_semantic_function
            result = await self.execute_semantic_function(skill_name, function_name, parameters)
            
            # Generate a natural language response
            # FIX: Replaced 'gpt-35-turbo' with 'gpt-4o-mini'
            nl_response = await self.azure_service.invoke_model(
                messages=[
                    {"role": "system", "content": "You are a helpful healthcare assistant. Format the following result into a natural response:"},
                    {"role": "user", "content": f"Result: {result}"}
                ],
                deployment_id="gpt-4o-mini"
            )
            
            return {
                "agent_id": "semantic_kernel",
                "conversation_id": context.get("conversation_id") if context else None,
                "message": nl_response["choices"][0]["message"]["content"],
                "semantic_function": {
                    "skill": skill_name,
                    "function": function_name,
                    "parameters": parameters
                }
            }
        except Exception as e:
            print(f"Error processing with Semantic Kernel: {e}")
            raise
    
    # FIX: Rewrote to be async and use modern kernel.invoke
    async def execute_semantic_function(self, plugin_name: str, function_name: str, parameters: Dict[str, Any]) -> str:
        """Execute a Semantic Kernel function"""
        if not self._sk_initialized:
            return "Error: Semantic Kernel not initialized"
        
        try:
            # Create kernel arguments from parameters
            import semantic_kernel as sk
            kernel_args = sk.KernelArguments(**parameters)
            
            # Invoke the function
            result = await self._sk_kernel.invoke(
                plugin_name=plugin_name,
                function_name=function_name,
                arguments=kernel_args
            )
            return str(result)
        except Exception as e:
            print(f"Error executing semantic function: {e}")
            return f"Error: {str(e)}"


    async def execute_hybrid_task(self, user_id: str, message: str, context: Dict[str, Any] = None):
        """Execute a hybrid task using both LLM and Semantic Kernel"""
        if not self._sk_initialized:
            return await self.route_request(user_id, message, context=context)

        # Create a plan using the LLM
        system_message = """
        You are a healthcare planning assistant. Break down complex health tasks into steps.
        Some steps will require semantic functions, while others will need LLM reasoning.

        Available semantic functions:
        - appointment.schedule_appointment(date, time, provider)
        - appointment.get_upcoming_appointments(user_id)
        - medication.get_medication_info(medication)
        - medication.check_interactions(medications)
        - health_metrics.log_metrics(metrics)
        - health_metrics.analyze_metrics(metrics)
        - nutrition.generate_meal_plan(goal, restrictions)
        - nutrition.check_food_interactions(medication, food)

        Respond with a JSON array of steps:
        [
            {
                "type": "semantic_function",
                "skill": "skill_name",
                "function": "function_name",
                "parameters": {"param1": "value1"}
            },
            {
                "type": "llm_reasoning",
                "task": "description of reasoning task"
            }
        ]
        """

        # Get the plan
        plan_response = await self.azure_service.invoke_model(
            messages=[
                {"role": "system", "content": system_message},
                {"role": "user", "content": message}
            ],
            deployment_id="gpt-4o-mini" # This was already correct
        )

        try:
            # Extract and execute the plan
            plan_text = plan_response["choices"][0]["message"]["content"]
            plan = json.loads(plan_text)
            
            # Execute each step
            results = []
            for step in plan:
                step_type = step.get("type")
                
                if step_type == "semantic_function":
                    # Execute semantic function
                    skill_name = step.get("skill")
                    function_name = step.get("function")
                    parameters = step.get("parameters", {})
                    
                    # Add user_id if needed
                    if "user_id" not in parameters and function_name in [
                        "schedule_appointment", "get_upcoming_appointments", "track_mood"
                    ]:
                        parameters["user_id"] = user_id
                    
                    # Execute the function
                    # FIX: Await the async execute_semantic_function
                    result = await self.execute_semantic_function(skill_name, function_name, parameters)
                    results.append({
                        "step_type": "semantic_function",
                        "skill": skill_name,
                        "function": function_name,
                        "result": result
                    })
                
                elif step_type == "llm_reasoning":
                    # Execute LLM reasoning
                    task = step.get("task")
                    reasoning_context = f"Previous steps results: {json.dumps(results)}\n\nTask: {task}"
                    
                    # FIX: Replaced 'gpt-35-turbo' with 'gpt-4o-mini'
                    reasoning_response = await self.azure_service.invoke_model(
                        messages=[
                            {"role": "system", "content": "You are a healthcare assistant helping with a multi-step task."},
                            {"role": "user", "content": reasoning_context}
                        ],
                        deployment_id="gpt-4o-mini"
                    )
                    
                    reasoning_result = reasoning_response["choices"][0]["message"]["content"]
                    results.append({
                        "step_type": "llm_reasoning",
                        "task": task,
                        "result": reasoning_result
                    })
            
            # Generate final response
            final_response_prompt = f"""
            You are a healthcare assistant providing a response to the user.
            The user's original request was: "{message}"
            
            The following steps were executed to address this request:
            {json.dumps(results, indent=2)}
            
            Please provide a comprehensive, natural language response that addresses the user's request
            based on the results of these steps. Be conversational and helpful.
            """
            
            # FIX: Replaced 'gpt-35-turbo' with 'gpt-4o-mini'
            final_response = await self.azure_service.invoke_model(
                messages=[
                    {"role": "system", "content": "You are a helpful healthcare assistant."},
                    {"role": "user", "content": final_response_prompt}
                ],
                deployment_id="gpt-4o-mini"
            )
            
            return {
                "agent_id": "hybrid_orchestrator",
                "conversation_id": context.get("conversation_id") if context else None,
                "message": final_response["choices"][0]["message"]["content"],
                "execution_plan": plan,
                "step_results": results
            }
            
        except Exception as e:
            print(f"Error executing hybrid task: {e}")
            # Fall back to standard routing if hybrid execution fails
            return await self.route_request(user_id, message, context=context)