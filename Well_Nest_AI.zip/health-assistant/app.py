import streamlit as st
import asyncio
import sys
from pathlib import Path
import os

# --- Add project root to path ---
# This is crucial so Streamlit can find the 'main' module
# and other project modules (utils, agents, etc.)
# We assume this file is in ui/streamlit_ui_agent.py
# So, the project root is two levels up (parent.parent)
PROJECT_ROOT = Path(__file__).resolve().parent.parent

if str(PROJECT_ROOT) not in sys.path:
    sys.path.append(str(PROJECT_ROOT))

# Now we can import from the project
try:
    from main import setup_orchestrator
    from orchestrator.orchestrator_agent import OrchestratorAgent
except ImportError as e:
    st.error(f"Failed to import project modules. Ensure streamlit_ui_agent.py is in the 'ui' folder. Error: {e}")
    st.stop()

# --- Event Loop Management ---
@st.cache_resource
def get_event_loop():
    """
    Gets or creates a new event loop for the Streamlit app.
    This loop will be reused across all sessions and requests.
    """
    print("Getting or creating event loop...")
    try:
        # Try to get the running loop in the current thread
        loop = asyncio.get_running_loop()
    except RuntimeError:
        # If no loop is running, create a new one
        print("No running loop, creating new one.")
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
    return loop

# --- Orchestrator Setup ---
@st.cache_resource(show_spinner="Initializing Health Assistant...")
def get_orchestrator():
    """
    Initializes and caches the OrchestratorAgent using the persistent event loop.
    This runs only once.
    """
    print("Initializing orchestrator for Streamlit...")
    # Get the persistent event loop
    loop = get_event_loop()
    try:
        # Run the async setup function *in our persistent loop*
        orchestrator = loop.run_until_complete(setup_orchestrator())
        print("Orchestrator initialized successfully.")
        return orchestrator
    except Exception as e:
        print(f"Error during orchestrator setup: {e}")
        # Re-raise to be caught by Streamlit's error handling
        raise

# --- Main UI ---
def start_streamlit():
    """
    Sets up and runs the Streamlit chat interface.
    """
    st.set_page_config(page_title="AI Health Assistant", layout="centered")
    st.title("AI Health Assistant")
    st.caption("Your personal AI-powered health companion.")

    # --- Initialize Orchestrator ---
    try:
        orchestrator: OrchestratorAgent = get_orchestrator()
    except Exception as e:
        st.error(f"Fatal Error: Could not initialize the AI Health Assistant.")
        st.exception(e)
        st.warning("Please check the console/logs for more details. The app cannot continue.")
        st.stop()

    # --- Initialize Chat History ---
    if "messages" not in st.session_state:
        st.session_state.messages = []
        # Add a welcome message
        welcome_message = "Hello! I am your AI Health Assistant. How can I help you today?"
        st.session_state.messages.append({"role": "assistant", "content": welcome_message})

    # --- Display Chat History ---
    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])

    # --- Handle User Input ---
    if prompt := st.chat_input("How can I help you today?"):
        # 1. Add user message to history and display it
        st.session_state.messages.append({"role": "user", "content": prompt})
        with st.chat_message("user"):
            st.markdown(prompt)

        # 2. Get response from the orchestrator
        with st.chat_message("assistant"):
            with st.spinner("Thinking..."):
                try:
                    # Get the *same* persistent event loop
                    loop = get_event_loop()
                    session_id = "streamlit_user"
                    
                    # Run the async route_request method *in our persistent loop*
                    # instead of using asyncio.run()
                    response_data = loop.run_until_complete(
                        orchestrator.route_request(prompt, session_id)
                    )
                    
                    # --- Extract the message from the response ---
                    # The orchestrator returns a dictionary (like the one you pasted)
                    # We need to extract the user-facing 'message' string.
                    if isinstance(response_data, dict) and 'message' in response_data:
                        response_message = response_data['message']
                    elif isinstance(response_data, str):
                        # Fallback in case it's already a string
                        response_message = response_data
                    else:
                        # Handle unexpected response structures
                        print(f"Unexpected response format: {response_data}")
                        response_message = "Sorry, I received an unexpected response from the system."

                    # Display the response
                    st.markdown(response_message)
                    
                    # 3. Add assistant response to history
                    st.session_state.messages.append({"role": "assistant", "content": response_message})

                except Exception as e:
                    error_message = f"Sorry, I encountered an error: {e}"
                    st.error(error_message)
                    st.session_state.messages.append({"role": "assistant", "content": error_message})

# --- Entry Point ---
if __name__ == "__main__":
    # This block is executed when you run `streamlit run ui/streamlit_ui_agent.py`
    os.environ["INTERFACE_TYPE"] = "STREAMLIT"
    start_streamlit()