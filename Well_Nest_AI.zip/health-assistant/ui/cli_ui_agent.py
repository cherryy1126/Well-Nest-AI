import asyncio
import os
import sys
import time
from typing import Dict, Any
from datetime import datetime
from orchestrator.orchestrator_agent import OrchestratorAgent

# Add parent directory to path to import from agents
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import FunctionRegistry and WorkflowManager
from function_calling.function_registry import FunctionRegistry
from process_framework.workflow_manager import WorkflowManager
from utils.model_selector import ModelSelector
from utils.azure_ai_service import AzureAIAgentService

async def start_cli(orchestrator: OrchestratorAgent):
    """Start the CLI interface
    
    Args:
        orchestrator: Orchestrator agent
    """
    # WellNeSS AI ASCII art logo
    logo = """
    🌿 🏡 🌿 🏡 🌿 🏡 🌿 🏡 🌿 🏡 🌿 🏡 🌿 🏡 🌿
      ___        ___     _ _   _   _            _      _      ___ 
      \  \      /  /    | | | | \ | |          | |    / \    |_ _|
       \  \    /  / ___ | | | |  \| |  ___ ___ | |_  / _ \    | | 
        \  \/\/  / / _ \| | | | . ` | / _ / __|| __|| ___ \   | | 
         \  /\  / |  __/| | | | |\  | |  __\__\| |_ | | | |  _| |_
          \/  \/   \___||_|_| |_| \_| \___/___/ \__||_| |_| |_____|
    
    🌿 🏡 🌿 🏡 🌿 🏡 🌿 🏡 🌿 🏡 🌿 🏡 🌿 🏡 🌿
    """
    
    print(logo)
    print("Compassionate care for golden years")
    print("===================================")
    print("Type 'help' for available commands or 'exit' to quit")
    print()
    
    # Get current time to greet user appropriately
    current_hour = datetime.now().hour
    if 5 <= current_hour < 12:
        greeting = "Good morning"
    elif 12 <= current_hour < 18:
        greeting = "Good afternoon"
    else:
        greeting = "Good evening"
    
    print(f"🌞 {greeting}! How can WellNest AI assist you today?")
    print()
    
    conversation_id = None
    user_id = "cli_user"  # Default user ID for CLI
    
    while True:
        # Get user input
        user_input = input("👤 You: ")
        
        # Process commands
        if user_input.lower() == "exit":
            print("👋 Thank you for using WellNest AI. Take care and stay well!")
            break
            
        elif user_input.lower() == "help":
            print("\n📋 WellNest AI Commands:")
            print("   exit - Exit the application")
            print("   help - Show this help message")
            print("   clear - Clear the screen")
            print("   stats - Show usage statistics")
            print("   features - Show available features")
            
            print("\n🌟 WellNest AI Features:")
            print("   💬 Health Assistant - Ask any health-related questions")
            print("   ❤️‍🩹 Health Metrics - Track and monitor your health parameters")
            print("   😊 Mental Health - Track mood and get wellness suggestions")
            print("   🌾 Nutrition - Get personalized meal plans and dietary advice")
            print("   📅 Appointments - Schedule and manage healthcare appointments")
            print("   💊 Medications - Track and get information about medications")
            print("   🔄 Care Coordination - Coordinate care across providers")
            print("   🚨 Emergency - Get guidance for urgent health situations")
            
            print("\n💬 Example Queries:")
            print("   How am I feeling today? (Mental Health)")
            print("   My blood pressure is 120/80 (Health Metrics)")
            print("   What should I eat for dinner with diabetes? (Nutrition)")
            print("   Schedule an appointment with Dr. Smith (Appointments)")
            print("   Remind me to take my medication (Medications)")
            print("   I need to coordinate my care plan (Care Coordination)")
            print("   I'm having chest pain (Emergency)")
            print()
            continue
            
        elif user_input.lower() == "clear":
            os.system('cls' if os.name == 'nt' else 'clear')
            print(logo)
            print("Compassionate care for golden years")
            print("===================================")
            continue
            
        elif user_input.lower() == "stats":
            stats = orchestrator.get_usage_stats()
            print("\n📊 WellNest AI Usage Statistics:")
            print(f"   Total interactions: {stats.get('total_calls', 0)}")
            print(f"   Total tokens: {stats.get('total_tokens', 0)}")
            
            if 'agent_usage' in stats and stats['agent_usage']:
                print("\n👥 Feature Usage:")
                for agent_id, agent_stats in stats['agent_usage'].items():
                    feature_name = get_feature_name(agent_id)
                    print(f"   {get_agent_emoji(agent_id)} {feature_name}: {agent_stats.get('calls', 0)} interactions")
            print()
            continue
            
        elif user_input.lower() == "features":
            print("\n🌟 WellNest AI Features:")
            print("   💬 Health Assistant - Ask any health-related questions")
            print("   ❤️‍🩹 Health Metrics - Track and monitor your health parameters")
            print("   😊 Mental Health - Track mood and get wellness suggestions")
            print("   🌾 Nutrition - Get personalized meal plans and dietary advice")
            print("   📅 Appointments - Schedule and manage healthcare appointments")
            print("   💊 Medications - Track and get information about medications")
            print("   🔄 Care Coordination - Coordinate care across providers")
            print("   🚨 Emergency - Get guidance for urgent health situations")
            print()
            continue
        
        # Show typing indicator with animation
        for _ in range(3):
            for char in "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏":
                print(f"\r🤔 WellNest AI is thinking {char}", end="")
                await asyncio.sleep(0.1) # Use asyncio.sleep in async function
        
        # Process the request
        try:
            # FIX: Removed context_override to allow orchestrator to route freely
            response = await orchestrator.route_request(
                user_id=user_id,
                message=user_input,
                conversation_id=conversation_id
            )
            
            # Clear the thinking indicator
            print("\r" + " " * 40, end="\r")
            
            # Update conversation ID for the next request
            conversation_id = response.get("conversation_id")
            
            # Get the agent that responded
            agent_id = response.get("agent_id", "")
            agent_emoji = get_agent_emoji(agent_id)
            feature_name = get_feature_name(agent_id)
            
            # Display the response with feature name
            print(f"{agent_emoji} WellNest AI ({feature_name}): {response.get('message', 'No response')}")
            print()
            
            # If there's a follow-up response (from function calls), display it too
            if "follow_up_response" in response:
                follow_up = response["follow_up_response"]
                if isinstance(follow_up, dict) and "message" in follow_up:
                    print(f"{agent_emoji} WellNest AI ({feature_name}): {follow_up.get('message', '')}")
                elif isinstance(follow_up, dict) and "choices" in follow_up:
                    print(f"{agent_emoji} WellNest AI ({feature_name}): {follow_up['choices'][0]['message']['content']}")
                print()
                
            # Add a daily wellness tip occasionally (every 3 interactions)
            if orchestrator.get_usage_stats().get('total_calls', 0) % 3 == 0:
                print("💡 Daily Wellness Tip: Remember to stay hydrated and take short breaks to stretch throughout the day.")
                print()
                
        except Exception as e:
            # Clear the thinking indicator
            print("\r" + " " * 40, end="\r")
            print(f"❌ Error: {str(e)}")
            print("Please try again or type 'help' for assistance.")
            print()
            
def get_agent_emoji(agent_id: str) -> str:
    """Get an emoji for an agent based on its ID
    
    Args:
        agent_id: Agent ID
        
    Returns:
        Emoji string
    """
    emoji_map = {
        "appointment_agent": "📅",
        "medication_agent": "💊",
        "health_metrics_agent": "❤️‍🩹",
        "mental_health_agent": "😊",
        "nutrition_agent": "🌾",
        "care_coordination_agent": "🔄",
        "emergency_response_agent": "🚨",
        "semantic_kernel": "🧩",
        "hybrid_orchestrator": "🔄"
    }
    
    return emoji_map.get(agent_id, "🌿")

def get_feature_name(agent_id: str) -> str:
    """Get a user-friendly feature name for an agent
    
    Args:
        agent_id: Agent ID
        
    Returns:
        Feature name
    """
    feature_map = {
        "appointment_agent": "Appointments",
        "medication_agent": "Medications",
        "health_metrics_agent": "Health Metrics",
        "mental_health_agent": "Mental Health",
        "nutrition_agent": "Nutrition",
        "care_coordination_agent": "Care Coordination",
        "emergency_response_agent": "Emergency",
        "semantic_kernel": "Health Assistant",
        "hybrid_orchestrator": "Health Assistant"
    }
    
    return feature_map.get(agent_id, "Health Assistant")
        
def main():
    """Main entry point for CLI"""
    print("🌿 Initializing WellNest AI...")
    
    # Initialize services
    azure_service = AzureAIAgentService()
    
    # FIX: Initialize ModelSelector with correct models
    model_selector = ModelSelector(
        default_model="gpt-4o-mini",
        advanced_model="gpt-5-chat"
    )
    
    # FIX: Initialize FunctionRegistry and WorkflowManager
    function_registry = FunctionRegistry()
    workflow_manager = WorkflowManager()
    
    # FIX: Pass all required arguments to OrchestratorAgent
    orchestrator = OrchestratorAgent(
        azure_service=azure_service, 
        model_selector=model_selector,
        function_registry=function_registry,
        workflow_manager=workflow_manager
    )
    
    # Register all agents
    # FIX: Standardized agent import paths
    from agents.appointment_agent.appointment_agent import AppointmentAgent
    from agents.medication_agent.medication_agent import MedicationAgent
    from agents.health_metrics_agent.health_metrics_agent import HealthMetricsAgent
    from agents.mental_health_agent.mental_health_agent import MentalHealthAgent
    from agents.nutrition_agent.nutrition_agent import NutritionAgent
    from agents.care_coordination_agent.care_coordination_agent import CareCoordinationAgent
    from agents.emergency_response_agent.emergency_response_agent import EmergencyResponseAgent
    
    # Create data directory path
    data_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")
    
    print("🌿 Loading health data...")
    
    # Initialize all agents with the same data directory
    appointment_agent = AppointmentAgent(azure_service, data_dir=data_dir)
    medication_agent = MedicationAgent(azure_service, data_dir=data_dir)
    health_metrics_agent = HealthMetricsAgent(azure_service, data_dir=data_dir)
    mental_health_agent = MentalHealthAgent(azure_service, data_dir=data_dir)
    nutrition_agent = NutritionAgent(azure_service, data_dir=data_dir)
    care_coordination_agent = CareCoordinationAgent(azure_service, data_dir=data_dir)
    emergency_response_agent = EmergencyResponseAgent(azure_service, data_dir=data_dir)
    
    # Register all agents with the orchestrator
    orchestrator.register_agent("appointment_agent", "Appointment Agent", "appointment", appointment_agent)
    orchestrator.register_agent("medication_agent", "Medication Agent", "medication", medication_agent)
    orchestrator.register_agent("health_metrics_agent", "Health Metrics Agent", "health_monitoring", health_metrics_agent)
    orchestrator.register_agent("mental_health_agent", "Mental Health Agent", "mental_health", mental_health_agent)
    orchestrator.register_agent("nutrition_agent", "Nutrition Agent", "nutrition", nutrition_agent)
    orchestrator.register_agent("care_coordination_agent", "Care Coordination Agent", "care_coordination", care_coordination_agent)
    orchestrator.register_agent("emergency_response_agent", "Emergency Response Agent", "emergency", emergency_response_agent)
    
    # Try to initialize Semantic Kernel
    try:
        # This call now happens inside the Orchestrator's __init__
        # orchestrator.initialize_semantic_kernel() 
        if orchestrator._sk_initialized:
            print("✅ Advanced reasoning capabilities initialized")
        else:
            print("⚠️ Advanced reasoning capabilities (Semantic Kernel) not loaded.")
    except Exception as e:
        print(f"⚠️ Advanced reasoning initialization failed: {e}")
    
    print("✅ WellNest AI is ready to assist you!")
    print()
    
    # Start the CLI
    asyncio.run(start_cli(orchestrator))

if __name__ == "__main__":
    main()