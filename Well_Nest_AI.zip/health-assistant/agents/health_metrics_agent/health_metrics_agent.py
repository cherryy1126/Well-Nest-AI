from typing import Dict, Any, Optional
import json
import os
import pandas as pd

class HealthMetricsAgent:
    """Agent responsible for tracking and analyzing health metrics"""

    def __init__(self, azure_service, data_dir=None):
        """Initialize the health metrics agent
        
        Args:
            azure_service: Azure AI service for model invocation
            data_dir: Directory containing data files (optional)
        """
        self.azure_service = azure_service
        
        # Use default path if none provided
        if data_dir is None:
            # FIX: Correctly go up three directories (agent_file -> agents -> health-assistant)
            base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            self.data_dir = os.path.join(base_dir, "data")
        else:
            self.data_dir = data_dir
            
        # Load data files
        self.load_data_files()
    
    def load_data_files(self):
        """Load data from JSON files"""
        try:
            # Load health metrics data
            # (Assuming 'Health Metrics.json' based on README/previous errors)
            health_metrics_path = os.path.join(self.data_dir, "Health Metrics.json")
            self.health_metrics_data = pd.read_json(health_metrics_path)
            
            # Load health goals data
            # (Assuming 'Health Goals.json' based on README/previous errors)
            health_goals_path = os.path.join(self.data_dir, "Health Goals.json")
            self.health_goals_data = pd.read_json(health_goals_path)
            
            print("Successfully loaded health metrics data files")
        except Exception as e:
            print(f"Error loading data files: {e}")
            # Initialize empty dataframes as fallback
            self.health_metrics_data = pd.DataFrame()
            self.health_goals_data = pd.DataFrame()
    
    async def process_request(self, user_id: str, message: str, context: Optional[Dict[str, Any]] = None):
        """Process health metrics requests

        Args:
            user_id: User ID
            message: User message
            context: Additional context

        Returns:
            Response dictionary
        """
        # Create system message for health metrics agent
        system_message = """
        You are a Health Metrics Agent for healthcare services.
        Help users track health metrics, analyze trends, and set health goals.
        Always be clear and precise about health data and recommendations.
        """

        # Add available functions for this agent
        functions = [
            {
                "name": "get_user_health_data",
                "description": "Get health metrics and goals for a user",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "user_id": {"type": "string", "description": "User ID"}
                    },
                    "required": ["user_id"]
                }
            }
        ]

        # Prepare messages
        messages = [
            {"role": "system", "content": system_message},
            {"role": "user", "content": message}
        ]

        # Select appropriate model
        # FIX: Use the new default model from azure_ai_service.py
        model = "gpt-4o-mini"

        # Invoke model with function calling
        try:
            response = await self.azure_service.invoke_model(
                messages=messages,
                deployment_id=model,
                functions=functions
            )
        except Exception as e:
            print(f"Error invoking model: {e}")
            return {
                "agent_id": "health_metrics_agent",
                "message": "I'm sorry, I encountered an error processing your request.",
                "error": str(e)
            }

        # Check for function calls in the response
        function_call = None
        if (response.get("choices") and 
            response["choices"][0].get("message") and 
            (response["choices"][0]["message"].get("function_call") or 
             response["choices"][0]["message"].get("tool_calls"))):
            
            # Handle both function_call and tool_calls formats
            if response["choices"][0]["message"].get("function_call"):
                function_call = response["choices"][0]["message"]["function_call"]
                function_name = function_call.get("name")
                try:
                    function_args = json.loads(function_call.get("arguments", "{}"))
                except json.JSONDecodeError:
                    function_args = {}
            else:  # tool_calls format
                tool_calls = response["choices"][0]["message"]["tool_calls"]
                if tool_calls and len(tool_calls) > 0:
                    function_call = tool_calls[0].get("function", {})
                    function_name = function_call.get("name")
                    try:
                        function_args = json.loads(function_call.get("arguments", "{}"))
                    except json.JSONDecodeError:
                        function_args = {}
                else:
                    function_name = None
                    function_args = {}

            # Execute the appropriate function if a function call was found
            if function_name == "get_user_health_data":
                # Ensure user_id is set
                function_args["user_id"] = user_id
                result = self.get_user_health_data(user_id=function_args.get("user_id"))

                # Send the function result back to the model
                messages.append({
                    "role": "assistant",
                    "content": None,
                    "function_call": {
                        "name": function_name,
                        "arguments": json.dumps(function_args)
                    }
                })

                messages.append({
                    "role": "function",
                    "name": function_name,
                    "content": json.dumps(result)
                })

                # Get the final response
                try:
                    final_response = await self.azure_service.invoke_model(
                        messages=messages,
                        deployment_id=model
                    )
                    
                    return {
                        "agent_id": "health_metrics_agent",
                        "conversation_id": context.get("conversation_id") if context else None,
                        "message": final_response["choices"][0]["message"]["content"],
                        "model": model
                    }
                except Exception as e:
                    print(f"Error getting final response: {e}")
                    return {
                        "agent_id": "health_metrics_agent",
                        "message": "I found your health metrics data, but I'm having trouble analyzing it right now."
                    }
        
        # If no function call, return the direct response
        return {
            "agent_id": "health_metrics_agent",
            "conversation_id": context.get("conversation_id") if context else None,
            "message": response["choices"][0]["message"]["content"],
            "model": model
        }
    
    def get_user_health_data(self, user_id: str):
        """Get health metrics and goals for a user from the JSON data
        
        Args:
            user_id: User ID
            
        Returns:
            Dictionary with health metrics and goals
        """
        # Get health metrics for the user
        metrics = []
        if not self.health_metrics_data.empty:
            user_metrics = self.health_metrics_data[self.health_metrics_data['user_id'] == user_id]
            if not user_metrics.empty:
                metrics = user_metrics.to_dict('records')
        
        # Get health goals for the user
        goals = []
        if not self.health_goals_data.empty:
            user_goals = self.health_goals_data[self.health_goals_data['user_id'] == user_id]
            if not user_goals.empty:
                goals = user_goals.to_dict('records')
        
        return {
            "health_metrics": metrics,
            "health_goals": goals
        }