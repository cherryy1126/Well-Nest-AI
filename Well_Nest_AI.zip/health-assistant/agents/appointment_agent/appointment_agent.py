from typing import Dict, Any, Optional
import os
import json
import pandas as pd

class AppointmentAgent:
    """Agent responsible for managing healthcare appointments"""

    def __init__(self, azure_service, data_dir=None):
        """Initialize the appointment agent

        Args:
            azure_service: Azure AI service for model invocation
            data_dir: Directory containing data files (optional)
        """
        self.azure_service = azure_service
        
        # Use default path if none provided
        if data_dir is None:
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            self.data_dir = os.path.join(base_dir, "data")
        else:
            self.data_dir = data_dir
            
        # Load data files
        self.load_data_files()

    def load_data_files(self):
        """Load data from JSON files"""
        try:
            # Load appointments data
            appointments_path = os.path.join(self.data_dir, "appointments.json")
            self.appointments_data = pd.read_json(appointments_path)
            
            # Load healthcare providers data for provider information
            healthcare_providers_path = os.path.join(self.data_dir, "healthcare_providers.json")
            self.healthcare_providers = pd.read_json(healthcare_providers_path)
            
            print("Successfully loaded appointments data files")
        except Exception as e:
            print(f"Error loading data files: {e}")
            # Initialize empty dataframes as fallback
            self.appointments_data = pd.DataFrame()
            self.healthcare_providers = pd.DataFrame()

    async def process_request(self, user_id: str, message: str, context: Optional[Dict[str, Any]] = None):
        """Process appointment-related requests

        Args:
            user_id: User ID
            message: User message
            context: Additional context

        Returns:
            Response dictionary
        """
        # --- FIX: Updated System Message ---
        # Create system message for appointment agent
        system_message = """
        You are an Appointment Scheduling Agent for healthcare services.
        Your goal is to help users schedule, reschedule, or cancel appointments.

        **CRITICAL FLOW FOR NEW APPOINTMENTS:**
        1.  When a user first asks to book an appointment (e.g., "I need to book an appointment"), your *first* action should be to call the `get_user_appointments` function to see if they have any existing ones.
        2.  After getting the function result:
            - If they have appointments, list them.
            - If they have **no appointments**, inform them and ask for the details needed for a *new* appointment (Provider Name, Date, Time).
        3.  When the user provides the details (e.g., "Dr. Rahul, Jan 15th, 3 PM"), your *next* action is to call the `schedule_new_appointment` function with those details.
        4.  **DO NOT** call `get_user_appointments` again if the user is providing details for a *new* appointment.
        5.  Once `schedule_new_appointment` is successful, confirm this with the user.
        """
        # --- END FIX ---

        # --- FIX: Added new function definition ---
        # Add available functions for this agent
        functions = [
            {
                "name": "get_user_appointments",
                "description": "Get appointments for a user",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "user_id": {"type": "string", "description": "User ID"}
                    },
                    "required": ["user_id"]
                }
            },
            {
                "name": "schedule_new_appointment",
                "description": "Schedule a new appointment for a user with a specific provider, date, and time.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "user_id": {"type": "string", "description": "User ID"},
                        "provider_name": {"type": "string", "description": "The name of the healthcare provider, e.g., 'Dr. Rahul'"},
                        "date": {"type": "string", "description": "The date of the appointment, e.g., '2025-01-15'"},
                        "time": {"type": "string", "description": "The time of the appointment, e.g., '15:00'"},
                        "reason": {"type": "string", "description": "The reason for the visit, e.g., 'migraine' or 'fever'"}
                    },
                    "required": ["user_id", "provider_name", "date", "time"]
                }
            }
        ]
        # --- END FIX ---

        # --- FIX: Use conversation_history from context ---
        # Get conversation history from the context, default to empty list if not present
        # The orchestrator provides this history.
        if context:
            history = context.get("conversation_history", [])
        else:
            history = []

        # Prepare messages
        # Start with the system message
        messages = [{"role": "system", "content": system_message}]
        
        # Add the full conversation history
        # The history from the orchestrator already includes the *latest* user message.
        messages.extend(history)
        # --- END FIX ---

        # Select appropriate model
        # FIX: Use the new default model from azure_ai_service.py
        model = "gpt-4o-mini"

        # Invoke model with function calling
        try:
            response = await self.azure_service.invoke_model(
                messages=messages,
                deployment_id=model,
                functions=functions
            )
        except Exception as e:
            print(f"Error invoking model: {e}")
            return {
                "agent_id": "appointment_agent",
                "message": "I'm sorry, I encountered an error processing your request."
            }

        # Check for function calls in the response
        function_call = None
        if (response.get("choices") and 
            response["choices"][0].get("message") and 
            (response["choices"][0]["message"].get("function_call") or 
             response["choices"][0]["message"].get("tool_calls"))):
            
            # Handle both function_call and tool_calls formats
            if response["choices"][0]["message"].get("function_call"):
                function_call = response["choices"][0]["message"]["function_call"]
                function_name = function_call.get("name")
                try:
                    function_args = json.loads(function_call.get("arguments", "{}"))
                except json.JSONDecodeError:
                    function_args = {}
            else:  # tool_calls format
                tool_calls = response["choices"][0]["message"]["tool_calls"]
                if tool_calls and len(tool_calls) > 0:
                    function_call = tool_calls[0].get("function", {})
                    function_name = function_call.get("name")
                    try:
                        function_args = json.loads(function_call.get("arguments", "{}"))
                    except json.JSONDecodeError:
                        function_args = {}
                else:
                    function_name = None
                    function_args = {}

            # --- FIX: Handle new function call ---
            # Execute the appropriate function if a function call was found
            if function_name == "get_user_appointments":
                # Ensure user_id is set
                function_args["user_id"] = user_id
                result = self.get_user_appointments(user_id=function_args.get("user_id"))
            
            elif function_name == "schedule_new_appointment":
                # Ensure user_id is set
                function_args["user_id"] = user_id
                result = self.schedule_new_appointment(
                    user_id=user_id,
                    provider_name=function_args.get("provider_name"),
                    date=function_args.get("date"),
                    time=function_args.get("time"),
                    reason=function_args.get("reason")
                )
            
            else:
                # Handle unknown function
                result = {"error": f"Unknown function: {function_name}"}

            # Send the function result back to the model
            messages.append({
                "role": "assistant",
                "content": None,
                "function_call": {
                    "name": function_name,
                    "arguments": json.dumps(function_args)
                }
            })

            messages.append({
                "role": "function",
                "name": function_name,
                "content": json.dumps(result)
            })

            # Get the final response
            try:
                final_response = await self.azure_service.invoke_model(
                    messages=messages,
                    deployment_id=model
                )
                
                return {
                    "agent_id": "appointment_agent",
                    "conversation_id": context.get("conversation_id") if context else None,
                    "message": final_response["choices"][0]["message"]["content"],
                    "model": model
                }
            except Exception as e:
                print(f"Error getting final response: {e}")
                return {
                    "agent_id": "appointment_agent",
                    "message": "I found your appointment information, but I'm having trouble analyzing it right now."
                }
            # --- END FIX ---

        # If no function call, return the direct response
        return {
            "agent_id": "appointment_agent",
            "conversation_id": context.get("conversation_id") if context else None,
            "message": response["choices"][0]["message"]["content"],
            "model": model
        }

    def get_user_appointments(self, user_id: str):
        """Get appointments for a user from the JSON data
        
        Args:
            user_id: User ID
            
        Returns:
            Dictionary with appointment information
        """
        if self.appointments_data.empty:
            return {"appointments": [], "message": "No appointment data available."}
        
        # Filter appointments for the specified user
        user_appointments = self.appointments_data[self.appointments_data['user_id'] == user_id]
        
        if user_appointments.empty:
            return {"appointments": [], "message": f"No appointments found for user {user_id}."}
        
        # Get provider information
        providers = {}
        if not self.healthcare_providers.empty:
            for _, provider in self.healthcare_providers.iterrows():
                provider_id = provider.get('provider_id')
                if provider_id:
                    providers[provider_id] = {
                        "name": provider.get('name', ''),
                        "specialty": provider.get('specialty', ''),
                        "facility": provider.get('facility', '')
                    }
        
        # Sort appointments by date
        upcoming_appointments = user_appointments[user_appointments['status'] == 'Scheduled'].sort_values('date')
        completed_appointments = user_appointments[user_appointments['status'] == 'Completed'].sort_values('date', ascending=False)
        
        # Convert to list of dictionaries
        upcoming_list = upcoming_appointments.to_dict('records')
        completed_list = completed_appointments.to_dict('records')
        
        # Add provider details to each appointment
        for appt in upcoming_list + completed_list:
            provider_id = appt.get('provider_id')
            if provider_id in providers:
                appt['provider_details'] = providers[provider_id]
        
        return {
            "upcoming_appointments": upcoming_list,
            "past_appointments": completed_list,
            "count": len(upcoming_list) + len(completed_list)
        }

    # --- NEW: Add dummy function implementation ---
    def schedule_new_appointment(self, user_id: str, provider_name: str, date: str, time: str, reason: Optional[str] = None):
        """
        (Dummy) Schedule a new appointment.
        In a real app, this would write to the database.
        """
        print(f"--- DUMMY SCHEDULE ---")
        print(f"User: {user_id}")
        print(f"Provider: {provider_name}")
        print(f"Date: {date}, Time: {time}")
        print(f"Reason: {reason}")
        print(f"----------------------")

        # Create a dummy confirmation
        confirmation = {
            "status": "Scheduled",
            "appointment_id": f"dummy_{pd.Timestamp.now().timestamp()}",
            "user_id": user_id,
            "provider_name": provider_name,
            "date": date,
            "time": time,
            "reason": reason,
            "confirmation_message": f"Your appointment with {provider_name} on {date} at {time} has been successfully scheduled."
        }
        
        # We could also add this to self.appointments_data here
        # new_appt_df = pd.DataFrame([confirmation])
        # self.appointments_data = pd.concat([self.appointments_data, new_appt_df], ignore_index=True)
        # ... and then save to JSON ...
        
        return confirmation
    # --- END NEW ---