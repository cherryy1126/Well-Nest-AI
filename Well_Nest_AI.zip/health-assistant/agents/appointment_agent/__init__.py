# health-assistant/agents/appointment_agent/__init__.py

from .appointment_agent import AppointmentAgent

__all__ = ['AppointmentAgent']
