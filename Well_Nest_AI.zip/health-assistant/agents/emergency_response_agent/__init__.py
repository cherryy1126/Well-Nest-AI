# health-assistant/agents/emergency_response_agent/__init__.py

from .emergency_response_agent import EmergencyResponseAgent

__all__ = ['EmergencyResponseAgent']
