# health-assistant/agents/medication_agent/__init__.py

from .medication_agent import MedicationAgent

__all__ = ['MedicationAgent']

