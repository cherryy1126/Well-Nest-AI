from typing import Dict, Any, Optional
import json
import os
import pandas as pd

class MedicationAgent:
    """Agent responsible for medication management"""

    def __init__(self, azure_service, data_dir=None):
        """Initialize the medication agent
        
        Args:
            azure_service: Azure AI service for model invocation
            data_dir: Directory containing data files (optional)
        """
        self.azure_service = azure_service
        
        # Use default path if none provided
        if data_dir is None:
            # FIX: Correctly go up three directories (agent_file -> agents -> health-assistant)
            base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            self.data_dir = os.path.join(base_dir, "data")
        else:
            self.data_dir = data_dir
            
        # Load data files
        self.load_data_files()

    def load_data_files(self):
        """Load data from JSON files"""
        try:
            # Load medications data
            # FIX: Changed from .xlsx to .json
            medications_path = os.path.join(self.data_dir, "Medications.json")
            self.medications_data = pd.read_json(medications_path)
            
            print("Successfully loaded medications data file")
        except Exception as e:
            print(f"Error loading medications data file: {e}")
            # Initialize empty dataframe as fallback
            self.medications_data = pd.DataFrame()

    async def process_request(self, user_id: str, message: str, context: Optional[Dict[str, Any]] = None):
        """Process medication-related requests

        Args:
            user_id: User ID
            message: User message
            context: Additional context

        Returns:
            Response dictionary
        """
        # Create system message for medication agent
        system_message = """
        You are a Medication Management Agent for healthcare services.
        Help users track medications, set reminders, and provide information about medications.
        Always be clear and precise about medication dosages and schedules.
        """

        # Add available functions for this agent
        functions = [
            {
                "name": "get_user_medications",
                "description": "Get all medications for a user",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "user_id": {"type": "string", "description": "User ID"}
                    },
                    "required": ["user_id"]
                }
            }
        ]

        # Prepare messages
        messages = [
            {"role": "system", "content": system_message},
            {"role": "user", "content": message}
        ]
        
        # FIX: Use the advanced model for medication tasks, as defined in azure_ai_service.py
        model = "gpt-5-chat"

        # Invoke model with function calling
        try:
            response = await self.azure_service.invoke_model(
                messages=messages,
                deployment_id=model,
                functions=functions
            )
        except Exception as e:
            print(f"Error invoking model: {e}")
            return {
                "agent_id": "medication_agent",
                "message": "I'm sorry, I encountered an error processing your request."
            }

        # Check for function calls in the response
        function_call = None
        if (response.get("choices") and 
            response["choices"][0].get("message") and 
            (response["choices"][0]["message"].get("function_call") or 
             response["choices"][0]["message"].get("tool_calls"))):
            
            # Handle both function_call and tool_calls formats
            if response["choices"][0]["message"].get("function_call"):
                function_call = response["choices"][0]["message"]["function_call"]
                function_name = function_call.get("name")
                try:
                    function_args = json.loads(function_call.get("arguments", "{}"))
                except json.JSONDecodeError:
                    function_args = {}
            else:  # tool_calls format
                tool_calls = response["choices"][0]["message"]["tool_calls"]
                if tool_calls and len(tool_calls) > 0:
                    function_call = tool_calls[0].get("function", {})
                    function_name = function_call.get("name")
                    try:
                        function_args = json.loads(function_call.get("arguments", "{}"))
                    except json.JSONDecodeError:
                        function_args = {}
                else:
                    function_name = None
                    function_args = {}

            # Execute the appropriate function if a function call was found
            if function_name == "get_user_medications":
                # Ensure user_id is set
                function_args["user_id"] = user_id
                result = self.get_user_medications(user_id=function_args.get("user_id"))

                # Send the function result back to the model
                messages.append({
                    "role": "assistant",
                    "content": None,
                    "function_call": {
                        "name": function_name,
                        "arguments": json.dumps(function_args)
                    }
                })

                messages.append({
                    "role": "function",
                    "name": function_name,
                    "content": json.dumps(result)
                })

                # Get the final response
                try:
                    final_response = await self.azure_service.invoke_model(
                        messages=messages,
                        deployment_id=model
                    )
                    
                    return {
                        "agent_id": "medication_agent",
                        "conversation_id": context.get("conversation_id") if context else None,
                        "message": final_response["choices"][0]["message"]["content"],
                        "model": model
                    }
                except Exception as e:
                    print(f"Error getting final response: {e}")
                    return {
                        "agent_id": "medication_agent",
                        "message": "I found your medication information, but I'm having trouble analyzing it right now."
                    }

        # If no function call, return the direct response
        return {
            "agent_id": "medication_agent",
            "conversation_id": context.get("conversation_id") if context else None,
            "message": response["choices"][0]["message"]["content"],
            "model": model
        }
    
    def get_user_medications(self, user_id: str):
        """Get all medications for a user from the JSON data
        
        Args:
            user_id: User ID
            
        Returns:
            Dictionary with medication information
        """
        if self.medications_data.empty:
            return {"medications": [], "message": "No medication data available."}
        
        # Filter medications for the specified user
        user_medications = self.medications_data[self.medications_data['user_id'] == user_id]
        
        if user_medications.empty:
            return {"medications": [], "message": f"No medications found for user {user_id}."}
        
        # Convert to list of dictionaries
        medications_list = user_medications.to_dict('records')
        
        return {
            "medications": medications_list,
            "count": len(medications_list)
        }