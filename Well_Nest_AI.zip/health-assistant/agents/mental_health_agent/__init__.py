# health-assitant/agents/mental_health_agent/__init__.py

from .mental_health_agent import MentalHealthAgent

__all__ = ['MentalHealthAgent']
