from typing import Dict, Any, Optional
import os
import sys
import json
import pandas as pd

# Add parent directory to path to import from data
# FIX: Correctly go up three directories (agent_file -> agents -> health-assistant)
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

class MentalHealthAgent:
    """Agent responsible for mental health monitoring and support"""

    def __init__(self, azure_service, data_dir=None):
        """Initialize the mental health agent

        Args:
            azure_service: Azure AI service for model invocation
            data_dir: Directory containing data files (optional)
        """
        self.azure_service = azure_service
        
        # Use default path if none provided
        if data_dir is None:
            # FIX: Correctly go up three directories (agent_file -> agents -> health-assistant)
            base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            self.data_dir = os.path.join(base_dir, "data")
        else:
            self.data_dir = data_dir
            
        # Load data files
        self.load_data_files()

    def load_data_files(self):
        """Load data from JSON files"""
        try:
            # Load mental health data
            # FIX: Changed from .xlsx to .json
            mental_health_path = os.path.join(self.data_dir, "mental_health_data.json")
            self.mental_health_data = pd.read_json(mental_health_path)
            
            # Load user profiles
            # FIX: Changed from .xlsx to .json
            user_profiles_path = os.path.join(self.data_dir, "user_profiles.json")
            self.user_profiles = pd.read_json(user_profiles_path)
            
            print("Successfully loaded mental health data files")
        except Exception as e:
            print(f"Error loading data files: {e}")
            # Initialize empty dataframes as fallback
            self.mental_health_data = pd.DataFrame()
            self.user_profiles = pd.DataFrame()

    async def process_request(self, user_id: str, message: str, context: Optional[Dict[str, Any]] = None):
        """Process mental health-related requests

        Args:
            user_id: User ID
            message: User message
            context: Additional context

        Returns:
            Response dictionary
        """
        # Create system message for mental health agent
        system_message = """
        You are a Mental Health Support Agent, trained to provide empathetic and helpful responses to users 
        discussing mental health concerns. You can offer coping strategies, relaxation techniques, and general 
        mental wellness advice based on their historical data.
        
        When discussing the user's mental health data, reference their mood trends, stress levels, 
        and previous coping strategies that have worked for them.
        """

        # Add available functions for this agent
        functions = [
            {
                "name": "get_mental_health_data",
                "description": "Get the user's mental health data",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "user_id": {"type": "string", "description": "User ID"},
                        "days": {"type": "integer", "description": "Number of days of data to retrieve (default: 7)"}
                    },
                    "required": ["user_id"]
                }
            }
        ]

        # Prepare messages
        messages = [
            {"role": "system", "content": system_message},
            {"role": "user", "content": message}
        ]

        # Select appropriate model
        # FIX: Use the advanced model for mental health tasks, as defined in azure_ai_service.py
        model = "gpt-5-chat"

        # Invoke model with function calling
        try:
            response = await self.azure_service.invoke_model(
                messages=messages,
                deployment_id=model,
                functions=functions
            )
        except Exception as e:
            print(f"Error invoking model: {e}")
            return {
                "agent_id": "mental_health_agent",
                "message": f"I'm sorry, I encountered an error processing your request. Please try again later.",
                "error": str(e)
            }

        # Check for function calls in the response
        function_call = None
        if (response.get("choices") and 
            response["choices"][0].get("message") and 
            (response["choices"][0]["message"].get("function_call") or 
             response["choices"][0]["message"].get("tool_calls"))):
            
            # Handle both function_call and tool_calls formats
            if response["choices"][0]["message"].get("function_call"):
                function_call = response["choices"][0]["message"]["function_call"]
                function_name = function_call.get("name")
                try:
                    function_args = json.loads(function_call.get("arguments", "{}"))
                except json.JSONDecodeError:
                    function_args = {}
            else:  # tool_calls format
                tool_calls = response["choices"][0]["message"]["tool_calls"]
                if tool_calls and len(tool_calls) > 0:
                    function_call = tool_calls[0].get("function", {})
                    function_name = function_call.get("name")
                    try:
                        function_args = json.loads(function_call.get("arguments", "{}"))
                    except json.JSONDecodeError:
                        function_args = {}
                else:
                    function_name = None
                    function_args = {}

            # Execute the appropriate function if a function call was found
            if function_name == "get_mental_health_data":
                # Ensure user_id is set
                function_args["user_id"] = user_id
                result = self.get_mental_health_data(
                    user_id=function_args.get("user_id"),
                    days=function_args.get("days", 7)
                )

                # Send the function result back to the model
                messages.append({
                    "role": "assistant",
                    "content": None,
                    "function_call": {
                        "name": function_name,
                        "arguments": json.dumps(function_args)
                    }
                })

                messages.append({
                    "role": "function",
                    "name": function_name,
                    "content": json.dumps(result)
                })

                # Get the final response
                try:
                    final_response = await self.azure_service.invoke_model(
                        messages=messages,
                        deployment_id=model
                    )
                except Exception as e:
                    print(f"Error getting final response: {e}")
                    return {
                        "agent_id": "mental_health_agent",
                        "message": "I found your mental health data, but I'm having trouble analyzing it right now. Please try again later.",
                        "error": str(e)
                    }

                return {
                    "agent_id": "mental_health_agent",
                    "conversation_id": context.get("conversation_id") if context else None,
                    "message": final_response["choices"][0]["message"]["content"],
                    "usage": final_response.get("usage", {}),
                    "model": model
                }

        # If no function call, return the direct response
        return {
            "agent_id": "mental_health_agent",
            "conversation_id": context.get("conversation_id") if context else None,
            "message": response["choices"][0]["message"]["content"],
            "usage": response.get("usage", {}),
            "model": model
        }

    def get_mental_health_data(self, user_id: str, days: int = 7):
        """Get the user's mental health data

        Args:
            user_id: User ID
            days: Number of days of data to retrieve

        Returns:
            Dictionary with mental health data
        """
        if self.mental_health_data.empty:
            return {"error": "No mental health data available"}
            
        # Filter data for the specified user
        user_data = self.mental_health_data[self.mental_health_data['user_id'] == user_id]
        
        if user_data.empty:
            return {"error": f"No mental health data found for user {user_id}"}
            
        # Get user profile information
        user_profile = {}
        if not self.user_profiles.empty:
            profile_data = self.user_profiles[self.user_profiles['user_id'] == user_id]
            if not profile_data.empty:
                user_profile = profile_data.iloc[0].to_dict()
        
        # Take the most recent entries
        recent_data = user_data.sort_values('date', ascending=False).head(days)
        
        # Convert to list of dictionaries
        history = recent_data.to_dict('records')
        
        # Calculate some basic statistics
        if history:
            mood_ratings = [entry.get('mood_rating') for entry in history if 'mood_rating' in entry and entry['mood_rating'] is not None]
            stress_levels = [entry.get('stress_level') for entry in history if 'stress_level' in entry and entry['stress_level'] is not None]
            
            avg_mood = sum(mood_ratings) / len(mood_ratings) if mood_ratings else None
            avg_stress = sum(stress_levels) / len(stress_levels) if stress_levels else None
            
            stats = {
                "average_mood": avg_mood,
                "average_stress": avg_stress,
                "data_points": len(history)
            }
        else:
            stats = {
                "average_mood": None,
                "average_stress": None,
                "data_points": 0
            }
        
        return {
            "user_profile": user_profile,
            "mental_health_history": history,
            "statistics": stats
        }