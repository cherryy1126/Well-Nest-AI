# health-assistant/agents/nutrition_agent/__init__.py

from .nutrition_agent import NutritionAgent

__all__ = ['NutritionAgent']
