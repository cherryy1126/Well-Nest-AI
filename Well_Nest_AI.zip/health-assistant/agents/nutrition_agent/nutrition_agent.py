from typing import Dict, Any, Optional
import json
import os
import pandas as pd

class NutritionAgent:
    """Agent responsible for nutrition guidance and meal planning"""

    def __init__(self, azure_service, data_dir=None):
        """Initialize the nutrition agent
        
        Args:
            azure_service: Azure AI service for model invocation
            data_dir: Directory containing data files (optional)
        """
        self.azure_service = azure_service
        
        # Use default path if none provided
        if data_dir is None:
            # FIX: Correctly go up three directories (agent_file -> agents -> health-assistant)
            base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            self.data_dir = os.path.join(base_dir, "data")
        else:
            self.data_dir = data_dir
            
        # Load data files
        self.load_data_files()

    def load_data_files(self):
        """Load data from JSON files"""
        try:
            # Load nutrition data
            # FIX: Changed from .xlsx to .json
            nutrition_path = os.path.join(self.data_dir, "Nutrition Data.json")
            self.nutrition_data = pd.read_json(nutrition_path)
            
            # Load user profiles for basic user information
            # FIX: Changed from .xlsx to .json
            user_profiles_path = os.path.join(self.data_dir, "user_profiles.json")
            self.user_profiles = pd.read_json(user_profiles_path)
            
            print("Successfully loaded nutrition data files")
        except Exception as e:
            print(f"Error loading data files: {e}")
            # Initialize empty dataframes as fallback
            self.nutrition_data = pd.DataFrame()
            self.user_profiles = pd.DataFrame()

    async def process_request(self, user_id: str, message: str, context: Optional[Dict[str, Any]] = None):
        """Process nutrition-related requests

        Args:
            user_id: User ID
            message: User message
            context: Additional context

        Returns:
            Response dictionary
        """
        # Create system message for nutrition agent
        system_message = """
        You are a Nutrition Agent for healthcare services.
        Help users with meal plans, nutritional information, and food-medication interactions.
        Always consider dietary restrictions and health conditions when providing advice.
        Use the user's nutrition history data to provide personalized responses.
        """

        # Add available functions for this agent
        functions = [
            {
                "name": "get_user_nutrition_data",
                "description": "Get the user's nutrition data and profile information",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "user_id": {"type": "string", "description": "User ID"}
                    },
                    "required": ["user_id"]
                }
            }
        ]

        # Prepare messages
        messages = [
            {"role": "system", "content": system_message},
            {"role": "user", "content": message}
        ]
        
        # FIX: Use the new default model from azure_ai_service.py
        model = "gpt-4o-mini"

        # Invoke model with function calling
        try:
            response = await self.azure_service.invoke_model(
                messages=messages,
                deployment_id=model,
                functions=functions
            )
        except Exception as e:
            print(f"Error invoking model: {e}")
            return {
                "agent_id": "nutrition_agent",
                "message": "I'm sorry, I encountered an error processing your request."
            }

        # Check for function calls in the response
        function_call = None
        if (response.get("choices") and 
            response["choices"][0].get("message") and 
            (response["choices"][0]["message"].get("function_call") or 
             response["choices"][0]["message"].get("tool_calls"))):
            
            # Handle both function_call and tool_calls formats
            if response["choices"][0]["message"].get("function_call"):
                function_call = response["choices"][0]["message"]["function_call"]
                function_name = function_call.get("name")
                try:
                    function_args = json.loads(function_call.get("arguments", "{}"))
                except json.JSONDecodeError:
                    function_args = {}
            else:  # tool_calls format
                tool_calls = response["choices"][0]["message"]["tool_calls"]
                if tool_calls and len(tool_calls) > 0:
                    function_call = tool_calls[0].get("function", {})
                    function_name = function_call.get("name")
                    try:
                        function_args = json.loads(function_call.get("arguments", "{}"))
                    except json.JSONDecodeError:
                        function_args = {}
                else:
                    function_name = None
                    function_args = {}

            # Execute the appropriate function if a function call was found
            if function_name == "get_user_nutrition_data":
                # Ensure user_id is set
                function_args["user_id"] = user_id
                result = self.get_user_nutrition_data(user_id=function_args.get("user_id"))

                # Send the function result back to the model
                messages.append({
                    "role": "assistant",
                    "content": None,
                    "function_call": {
                        "name": function_name,
                        "arguments": json.dumps(function_args)
                    }
                })

                messages.append({
                    "role": "function",
                    "name": function_name,
                    "content": json.dumps(result)
                })

                # Get the final response
                try:
                    final_response = await self.azure_service.invoke_model(
                        messages=messages,
                        deployment_id=model
                    )
                    
                    return {
                        "agent_id": "nutrition_agent",
                        "conversation_id": context.get("conversation_id") if context else None,
                        "message": final_response["choices"][0]["message"]["content"],
                        "model": model
                    }
                except Exception as e:
                    print(f"Error getting final response: {e}")
                    return {
                        "agent_id": "nutrition_agent",
                        "message": "I found your nutrition data, but I'm having trouble analyzing it right now."
                    }

        # If no function call, return the direct response
        return {
            "agent_id": "nutrition_agent",
            "conversation_id": context.get("conversation_id") if context else None,
            "message": response["choices"][0]["message"]["content"],
            "model": model
        }
    
    def get_user_nutrition_data(self, user_id: str):
        """Get the user's nutrition data and profile information
        
        Args:
            user_id: User ID
            
        Returns:
            Dictionary with user nutrition data
        """
        # Get user profile information
        user_profile = {}
        if not self.user_profiles.empty:
            profile_data = self.user_profiles[self.user_profiles['user_id'] == user_id]
            if not profile_data.empty:
                # Extract relevant fields only
                profile = profile_data.iloc[0]
                user_profile = {
                    "name": profile.get("name", ""),
                    "age": profile.get("age", ""),
                    "gender": profile.get("gender", ""),
                    "allergies": profile.get("allergies", ""),
                    "chronic_conditions": profile.get("chronic_conditions", ""),
                    "height_cm": profile.get("height_cm", ""),
                    "weight_kg": profile.get("weight_kg", "")
                }
        
        # Get nutrition data
        nutrition_entries = []
        if not self.nutrition_data.empty:
            user_nutrition = self.nutrition_data[self.nutrition_data['user_id'] == user_id]
            if not user_nutrition.empty:
                # Get the most recent entries (up to 5)
                recent_entries = user_nutrition.sort_values('date', ascending=False).head(5)
                nutrition_entries = recent_entries.to_dict('records')
        
        return {
            "user_profile": user_profile,
            "recent_nutrition_entries": nutrition_entries
        }