from typing import Dict, Any, Optional
import json
import os
import pandas as pd

class CareCoordinationAgent:
    """Agent responsible for coordinating care across multiple healthcare providers"""
    
    def __init__(self, azure_service, data_dir=None):
        """Initialize the care coordination agent
        
        Args:
            azure_service: Azure AI service for model invocation
            data_dir: Directory containing data files (optional)
        """
        self.azure_service = azure_service
        
        # Use default path if none provided
        if data_dir is None:
            # FIX: Correctly go up three directories (agent_file -> agents -> health-assistant)
            base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            self.data_dir = os.path.join(base_dir, "data")
        else:
            self.data_dir = data_dir
            
        # Load data files
        self.load_data_files()
    
    def load_data_files(self):
        """Load data from JSON files"""
        try:
            # --- FIX: Load the users.json file ---
            users_path = os.path.join(self.data_dir, "users.json")
            # Load the 'users' list from the JSON file
            with open(users_path, 'r') as f:
                users_list = json.load(f).get("users", [])
            self.users_data = pd.DataFrame(users_list)
            # --- END FIX ---

            # Load care coordination data
            care_coordination_path = os.path.join(self.data_dir, "Care Coordination Data.json")
            self.care_coordination_data = pd.read_json(care_coordination_path)
            
            # Load healthcare providers data
            healthcare_providers_path = os.path.join(self.data_dir, "healthcare_providers.json")
            self.healthcare_providers = pd.read_json(healthcare_providers_path)
            
            # Load appointments data for coordination
            appointments_path = os.path.join(self.data_dir, "appointments.json")
            self.appointments = pd.read_json(appointments_path)
            
            print("Successfully loaded care coordination data files (including users.json)")
        except Exception as e:
            print(f"Error loading data files: {e}")
            # Initialize empty dataframes as fallback
            # --- FIX: Add users_data to fallback ---
            self.users_data = pd.DataFrame()
            # --- END FIX ---
            self.care_coordination_data = pd.DataFrame()
            self.healthcare_providers = pd.DataFrame()
            self.appointments = pd.DataFrame()
    
    async def process_request(self, user_id: str, message: str, context: Optional[Dict[str, Any]] = None):
        """Process care coordination requests
        
        Args:
            user_id: User ID (from orchestrator, e.g., 'streamlit_user')
            message: User message
            context: Additional context
            
        Returns:
            Response dictionary
        """
        # Create system message for care coordination agent
        system_message = """
        You are a Care Coordination Agent for healthcare services.
        Your role is to help coordinate care across multiple healthcare providers, track treatment plans,
        and ensure continuity of care. You help patients navigate the healthcare system efficiently.
        
        **CRITICAL FLOW:**
        1. Your first action is usually to call `get_care_coordination_data`.
        2. This function requires a `user_id`. If the user has not provided one in their message,
           you MUST ask them: "Could you please provide me with your user ID?"
        3. Once the user provides a `user_id` (like '6f6b34ea-0c83-45ce-9992-133335ba4bde'),
           you must call `get_care_coordination_data` AGAIN, this time passing the `user_id`
           you just received from the user.
        4. Use the data from that function call to answer the user's request.
        """
        
        # Add available functions for this agent
        functions = [
            {
                "name": "get_care_coordination_data",
                "description": "Get all care coordination data (profile, plans, appointments) for a specific user ID.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "user_id": {"type": "string", "description": "The specific user_id provided by the user, e.g., '6f6b34ea-0c83-45ce-9992-133335ba4bde'"}
                    },
                    "required": ["user_id"]
                }
            }
        ]
        
        # --- FIX: Use conversation_history from context ---
        # Get conversation history from the context, default to empty list if not present
        if context:
            history = context.get("conversation_history", [])
        else:
            history = []

        # Prepare messages
        # Start with the system message
        messages = [{"role": "system", "content": system_message}]
        
        # Add the full conversation history
        messages.extend(history)
        # --- END FIX ---
        
        # Use standard model for PoC
        model = "gpt-4o-mini"
        
        # Invoke model with function calling
        try:
            response = await self.azure_service.invoke_model(
                messages=messages,
                deployment_id=model,
                functions=functions
            )
        except Exception as e:
            print(f"Error invoking model: {e}")
            return {
                "agent_id": "care_coordination_agent",
                "message": "I'm sorry, I encountered an error processing your request."
            }
        
        # Check for function calls in the response
        function_call = None
        if (response.get("choices") and 
            response["choices"][0].get("message") and 
            (response["choices"][0]["message"].get("function_call") or 
             response["choices"][0]["message"].get("tool_calls"))):
            
            # Handle both function_call and tool_calls formats
            if response["choices"][0]["message"].get("function_call"):
                function_call = response["choices"][0]["message"]["function_call"]
                function_name = function_call.get("name")
                try:
                    function_args = json.loads(function_call.get("arguments", "{}"))
                except json.JSONDecodeError:
                    function_args = {}
            else:  # tool_calls format
                tool_calls = response["choices"][0]["message"]["tool_calls"]
                if tool_calls and len(tool_calls) > 0:
                    function_call = tool_calls[0].get("function", {})
                    function_name = function_call.get("name")
                    try:
                        function_args = json.loads(function_call.get("arguments", "{}"))
                    except json.JSONDecodeError:
                        function_args = {}
                else:
                    function_name = None
                    function_args = {}

            # Execute the appropriate function if a function call was found
            if function_name == "get_care_coordination_data":
                
                # --- FIX: Use user_id from AI's function call arguments ---
                # The AI will extract the user_id (e.g., '6f6b...') from the conversation.
                # We must use that, NOT the 'user_id' from the orchestrator ('streamlit_user').
                user_id_from_args = function_args.get("user_id")
                
                if not user_id_from_args:
                    # This happens if the AI tries to call the function without the required arg.
                    # We'll send back an "error" to the AI to prompt it to ask the user.
                    result = {"error": "user_id is required. Please ask the user for their user ID."}
                else:
                    # We have a user_id from the AI, so we pass it to our Python function.
                    print(f"--- CareCoordinationAgent: Calling get_care_coordination_data with user_id: {user_id_from_args} ---")
                    result = self.get_care_coordination_data(user_id=user_id_from_args)
                # --- END FIX ---

                # Send the function result back to the model
                messages.append({
                    "role": "assistant",
                    "content": None,
                    "function_call": {
                        "name": function_name,
                        "arguments": json.dumps(function_args)
                    }
                })

                messages.append({
                    "role": "function",
                    "name": function_name,
                    "content": json.dumps(result)
                })

                # Get the final response
                try:
                    final_response = await self.azure_service.invoke_model(
                        messages=messages,
                        deployment_id=model
                    )
                    
                    return {
                        "agent_id": "care_coordination_agent",
                        "conversation_id": context.get("conversation_id") if context else None,
                        "message": final_response["choices"][0]["message"]["content"],
                        "model": model
                    }
                except Exception as e:
                    print(f"Error getting final response: {e}")
                    return {
                        "agent_id": "care_coordination_agent",
                        "message": "I found your care coordination data, but I'm having trouble analyzing it right now."
                    }
        
        # If no function call, return the direct response
        return {
            "agent_id": "care_coordination_agent",
            "conversation_id": context.get("conversation_id") if context else None,
            "message": response["choices"][0]["message"]["content"],
            "model": model
        }
    
    # --- FIX: Rewritten function to pull from all data sources ---
    def get_care_coordination_data(self, user_id: str):
        """Get all care data for a user from the JSON data
        
        Args:
            user_id: User ID provided by the user
            
        Returns:
            Dictionary with all user-related information
        """
        if user_id is None:
            return {"error": "user_id cannot be null."}
            
        print(f"--- get_care_coordination_data: Searching for user_id: {user_id} ---")

        # Get user profile data
        user_profile = {}
        if not self.users_data.empty:
            user_record = self.users_data[self.users_data['user_id'] == user_id]
            if not user_record.empty:
                user_profile = user_record.to_dict('records')[0]
                print(f"Found user profile for: {user_profile.get('first_name')}")
        
        # Get care coordination data for the user
        care_plans = []
        if not self.care_coordination_data.empty:
            user_care_data = self.care_coordination_data[self.care_coordination_data['user_id'] == user_id]
            if not user_care_data.empty:
                care_plans = user_care_data.to_dict('records')
                print(f"Found {len(care_plans)} care plan(s).")
        
        # Get healthcare providers for the user
        # In a real app, user_profile might have a list of provider_ids to filter by.
        # For now, we'll just link appointments to providers.
        providers_lookup = {}
        if not self.healthcare_providers.empty:
             for _, provider in self.healthcare_providers.iterrows():
                providers_lookup[provider['provider_id']] = provider.to_dict()
        
        # Get upcoming appointments for the user
        appointments = []
        if not self.appointments.empty:
            user_appointments = self.appointments[self.appointments['user_id'] == user_id]
            if not user_appointments.empty:
                # Sort by date to get upcoming appointments
                upcoming_appointments = user_appointments[user_appointments['status'] == 'Scheduled'].sort_values('date')
                appointments_list = upcoming_appointments.to_dict('records')
                
                # Add provider details to appointments
                for appt in appointments_list:
                    provider_id = appt.get('provider_id')
                    if provider_id in providers_lookup:
                        appt['provider_details'] = providers_lookup[provider_id]
                appointments = appointments_list
                print(f"Found {len(appointments)} upcoming appointment(s).")

        # Check if any data was found
        if not user_profile and not care_plans and not appointments:
            print("--- No data found for this user_id ---")
            return {
                "message": f"No data found for user_id {user_id}. Please confirm the ID is correct."
            }

        return {
            "user_profile": user_profile,
            "care_plans": care_plans,
            "upcoming_appointments": appointments,
            "message": "Successfully retrieved user data."
        }
    # --- END FIX ---