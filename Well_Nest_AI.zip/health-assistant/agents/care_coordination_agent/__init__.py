# health-assistant/agents/care_coordination_agent/__init__.py

from .care_coordination_agent import CareCoordinationAgent

__all__ = ['CareCoordinationAgent']
